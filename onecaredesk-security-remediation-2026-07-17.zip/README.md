# 1. OneCareDesk

## 2. One-sentence summary

OneCareDesk is a multi-tenant operations prototype for home-care agencies, combining lead management, patient onboarding, caregiver coordination, scheduling, forms, signatures, and agency administration.

## 3. Problem addressed

Home-care teams often coordinate prospective clients, onboarding, caregivers, appointments, tasks, and document requests across disconnected tools. This prototype explores a single agency-scoped workspace for those operational workflows.

## 4. Current status

This repository is a development prototype undergoing security hardening. It uses Base44 managed authentication in application code, server-side authorization helpers for elevated backend operations, and agency-scoped entity rules. The changes in this repository have not been deployed or independently security tested. Do not use real healthcare or other sensitive personal data.

| Capability | Status | Notes |
| --- | --- | --- |
| Lead management | Implemented | Agency-scoped CRUD interface; workflow quality is not independently validated. |
| Patient workflows | Partial | Basic onboarding and record views exist; clinical correctness is out of scope. |
| Caregiver workflows | Partial | Basic records and coordination views exist. |
| Scheduling | Partial | Calendar and appointment workflows exist without production validation. |
| Forms and signatures | Partial | Jotform-based prototype and email flow; provider configuration and integration testing remain. |
| Base44 managed authentication | Implemented after migration | Local custom passwords and sessions were removed; Base44-side configuration is still required. |
| Server-side tenant authorization | Implemented after remediation | Shared function guards plus proposed entity RLS; deploy-time Base44 verification is required. |
| HIPAA compliance | Not verified | Independent legal, privacy, platform, and security review is required. |
| Production deployment | Not recommended | See known limitations and the manual configuration checklist. |

## 5. Main workflows

- Agency-scoped lead intake and conversion
- Patient and caregiver record coordination
- Appointment scheduling and work-queue tasks
- Form-template import and submission tracking
- Signature-request creation and authenticated form viewing
- Agency team role assignment through managed Base44 users
- Platform-level agency and user administration

All records used for demonstration must be synthetic.

## 6. Architecture

The React/Vite frontend delegates identity and session management to the Base44 SDK. Protected routes resolve the current managed user. Direct entity access is constrained by agency-level Base44 rules. Backend functions authenticate the request, derive role and agency from the managed user, authorize the operation, and only then use service-role access where it is necessary.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for boundaries, data flow, and trust assumptions.

## 7. Technology stack

Confirmed from `package.json` and source:

- React 18 and React DOM
- Vite 6 and the Base44 Vite plugin
- Base44 SDK and Base44 Deno backend functions
- React Router
- TanStack React Query
- Tailwind CSS
- React Hook Form and Zod
- Radix UI components
- Recharts
- Stripe client libraries
- Vitest for security regression tests

Presence of a library does not mean its related workflow is production-ready.

## 8. Authentication and authorization

Authentication is owned by Base44:

- The frontend calls `base44.auth.isAuthenticated()`, `base44.auth.me()`, `base44.auth.redirectToLogin()`, and `base44.auth.logout()`.
- Password entry, password hashing, password resets, invitations, tokens, and session lifecycle are not implemented by this application.
- The Base44 built-in `User.role === "admin"` is the trusted platform-admin signal.
- Agency roles are server-assigned User fields: `agency_admin`, `care_manager`, `caregiver`, and `read_only`.
- Backend functions use `requireAuthenticatedUser`, role checks, agency membership checks, and record ownership checks before elevated access.

The managed flow follows the [Base44 authentication SDK](https://docs.base44.com/developers/references/sdk/docs/interfaces/auth) and [login and registration configuration](https://docs.base44.com/Setting-up-your-app/Managing-login-and-registration). No old password hash is migrated.

## 9. Multi-tenant design

`User.agency_id` is the server-assigned tenant membership. Agency-owned entities require `agency_id`. Proposed Base44 entity rules compare record agency membership to the managed user's agency and separately allow the built-in platform-admin role.

Client filters improve usability but are not the security boundary. Requests that carry another agency ID or another tenant's record ID are rejected by backend authorization and entity rules. Service-role functions return only the minimum fields required by the caller.

## 10. Security hardening

The remediation removes the custom SHA-256 password system, shared salt, password-hash fields and comparisons, custom reset and invitation tokens, custom session objects, `localStorage.app_user`, emergency/debug login utilities, default admin bootstrap functions, client-side API-key configuration, raw webhook logging, and unrestricted service-role functions.

Additional controls include:

- Structured allowlisted security logs with redacted identifiers
- Bearer-secret gates for enabled webhook receivers
- Server-side record and role checks
- Update-field allowlists that block role and tenant escalation
- Jotform URL allowlisting and sandboxed embedding
- Environment-only provider secrets
- Public prototype and healthcare-data warnings
- Static and behavioral security regression tests

See [SECURITY_REMEDIATION_NOTES.md](SECURITY_REMEDIATION_NOTES.md) and [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md).

## 11. Synthetic demo data

Only invented people, agencies, appointments, forms, documents, and contact details may be used. Use reserved domains such as `example.invalid`, non-routable sample phone numbers, and obviously synthetic names. Do not import production exports or real medical records.

## 12. Setup

Prerequisites:

- Node.js 20 or 22
- npm
- A non-production Base44 application dedicated to synthetic test data
- Permission to configure Base44 authentication, User fields, entities, functions, and secrets

Install dependencies on Windows PowerShell with:

```powershell
npm.cmd install
```

Do not place secrets in source files or client-prefixed environment variables.

## 13. Environment configuration

Frontend, non-secret local configuration:

```text
VITE_BASE44_APP_ID=<synthetic-test-app-id>
VITE_BASE44_BACKEND_URL=<base44-backend-url-if-required>
```

Backend secrets must be configured in the Base44 function environment, never in `.env` committed to Git:

```text
RESEND_API_KEY
RESEND_FROM_EMAIL
RESEND_FROM_NAME
APP_BASE_URL
JOTFORM_API_KEY
JOTFORM_WEBHOOK_SECRET
BOLDSIGN_WEBHOOK_SECRET
```

Disable any provider integration whose secret, callback contract, and synthetic test flow have not been verified.

## 14. Running locally

```powershell
npm.cmd run dev
```

Local compilation does not reproduce hosted Base44 authentication, entity rules, invitation semantics, function secrets, or provider callbacks. Use only synthetic test accounts and data.

## 15. Lint, typecheck, and build

```powershell
npm.cmd run lint
npm.cmd run typecheck
npm.cmd run build
```

The Vite configuration enables legacy Base44 import transforms because the current source still uses generated `@/entities`, `@/functions`, and `@/integrations` imports.

## 16. Testing

```powershell
npm.cmd test
npm.cmd audit
```

Local tests validate shared authorization behavior, tenant-crossing rejection, role-escalation rejection, generic errors, redacted logs, protected-route classification, removal of custom-auth code, and service-role guard ordering.

The following must be tested against a dedicated hosted Base44 test app: managed login/logout, invitation single-use/expiry/revocation/email binding, password reset, token revocation, entity-rule enforcement, all service-role functions, webhook provider signatures or bearer delivery, and cross-tenant end-to-end cases.

## 17. Implemented versus planned

Implemented in this working tree:

- Managed Base44 frontend authentication boundary
- Platform-admin and agency-role separation
- Shared server authorization helpers
- Agency entity-rule definitions
- Removal of custom auth and dangerous admin utilities
- Redacted backend security events and removal of client debug logging
- Security tests and technical documentation

Planned or blocked until Base44/provider configuration:

- Re-invite all test users and revoke custom sessions
- Apply and verify User fields, entity rules, and auth settings in Base44
- Configure webhook delivery authentication and provider secrets
- Run hosted integration and cross-tenant tests
- Establish retention, backup, incident response, monitoring, and audit-log policies
- Independent application, privacy, legal, and penetration review

## 18. Healthcare and HIPAA disclaimer

> OneCareDesk is a development prototype and has not been verified for HIPAA compliance or production handling of protected health information.

No repository change establishes a business associate agreement, compliant hosting, encryption guarantees, retention rules, access-review process, breach response, or HIPAA compliance. Do not use real protected health information.

## 19. Known limitations

- The remediation is not deployed; the existing hosted application, if any, is unchanged.
- Base44-side auth settings, User fields, entity rules, and secrets require manual application and review; remote entity schemas must be pulled and merged because they were absent from the original repository.
- Historical custom account records and sessions require manual invalidation and secure deletion under an approved data procedure.
- Existing test accounts cannot reuse application-managed password hashes; they must be invited or reset through Base44.
- Provider callbacks are not integration tested. BoldSign remains disabled unless it can send the configured bearer secret; provider-native signature verification should replace this when its exact contract is confirmed.
- Signature links now require a managed Base44 session, which may not match an external-recipient workflow.
- Dependency advisories and legacy UI behavior require separate remediation.
- No production data classification, retention, deletion, backup, disaster-recovery, monitoring, incident-response, or access-review program is implemented here.
- Git history retains deleted insecure code and sample identifiers; review and approved history remediation may be needed before publication.

## 20. Author contribution

This security-remediation contribution maps the original authentication and authorization flow, replaces custom auth with Base44 managed identity, adds a tenant authorization layer and entity rules, removes backdoors and sensitive logging, secures provider boundaries, adds regression tests, and documents the architecture, threat model, migration, limitations, and remaining deployment work. It does not claim authorship of every original product screen or workflow.
