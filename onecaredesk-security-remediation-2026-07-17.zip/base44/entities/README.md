# Entity security definitions

These JSONC files add the tenant-security rules required by the remediated application. The agency-owned files intentionally define only the security-critical `agency_id` property because the original repository did not contain its remote Base44 entity schemas.

Do not blindly push these files over an existing Base44 app. In a linked, non-production synthetic-data app:

1. Back up and pull the current entity definitions with the current Base44 CLI.
2. Merge every existing field and validation rule with the checked-in `agency_id`, row-level security, and legacy-entity deny rules.
3. Review the merged diff. Do not enable `additionalProperties: false` unless every legitimate field is represented.
4. Push to the non-production app only after approval.
5. Verify cross-tenant create/read/update/delete behavior for every entity from two independent managed users.

The built-in User schema is different: `User.jsonc` contains custom fields only, following the Base44 User-schema contract. Confirm with a hosted negative test that ordinary users cannot write `agency_id`, `app_role`, or `membership_status`.
