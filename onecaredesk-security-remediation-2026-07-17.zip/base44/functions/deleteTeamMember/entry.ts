import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  AGENCY_MANAGER_ROLES,
  errorResponse,
  jsonResponse,
  requireAgencyRole,
  requireAuthenticatedUser,
  requireRecordAccess,
  securityLog,
  SecurityError,
} from '../_shared/security.ts';

Deno.serve(async (req) => {
  const started = Date.now();
  const base44 = createClientFromRequest(req);
  try {
    const principal = requireAgencyRole(await requireAuthenticatedUser(base44), AGENCY_MANAGER_ROLES);
    const { user_id } = await req.json();
    if (typeof user_id !== 'string' || !user_id || user_id === principal.id) {
      throw new SecurityError(403, 'invalid_target');
    }

    const target = await base44.asServiceRole.entities.User.get(user_id);
    if (!principal.isPlatformAdmin) {
      requireRecordAccess(principal, target);
      if (target.role === 'admin' || target.app_role === 'agency_admin') {
        throw new SecurityError(403, 'privileged_target_forbidden');
      }
    }

    await base44.asServiceRole.entities.User.update(user_id, {
      disabled: true,
      membership_status: 'revoked',
    });
    securityLog('team.delete', {
      result: 'allowed', userId: principal.id, agencyId: principal.agencyId, durationMs: Date.now() - started,
    });
    return jsonResponse({ success: true });
  } catch (error) {
    securityLog('team.delete', { result: 'denied', errorCategory: 'authorization', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
