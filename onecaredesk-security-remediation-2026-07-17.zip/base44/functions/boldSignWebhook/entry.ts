import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  errorResponse,
  jsonResponse,
  requireWebhookBearerSecret,
  securityLog,
  SecurityError,
} from '../_shared/security.ts';

const STATUS_MAP: Record<string, string> = {
  completed: 'completed',
  signed: 'completed',
  declined: 'declined',
  revoked: 'cancelled',
  expired: 'expired',
  sent: 'sent',
};

Deno.serve(async (req) => {
  const started = Date.now();
  try {
    requireWebhookBearerSecret(req, 'BOLDSIGN_WEBHOOK_SECRET');
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const documentId = String(body.documentId || body.document_id || '');
    const providerStatus = String(body.documentStatus || body.eventType || '').toLowerCase();
    const status = STATUS_MAP[providerStatus];
    if (!documentId || !status) throw new SecurityError(400, 'invalid_webhook_payload', 'Invalid event.');

    const requests = await base44.asServiceRole.entities.SignatureRequest.filter({ external_request_id: documentId });
    const signatureRequest = requests[0];
    if (!signatureRequest) throw new SecurityError(403, 'unknown_document');

    await base44.asServiceRole.entities.SignatureRequest.update(signatureRequest.id, {
      status,
      provider_event_received_at: new Date().toISOString(),
    });
    securityLog('boldsign.webhook', {
      result: 'accepted', agencyId: signatureRequest.agency_id, durationMs: Date.now() - started,
    });
    return jsonResponse({ success: true });
  } catch (error) {
    securityLog('boldsign.webhook', { result: 'rejected', errorCategory: 'webhook', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
