import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  errorResponse,
  jsonResponse,
  requireAuthenticatedUser,
  requirePlatformAdmin,
  securityLog,
  SecurityError,
} from '../_shared/security.ts';

const ALLOWED_AGENCY_FIELDS = [
  'name', 'contact_email', 'contact_phone', 'address', 'city', 'state', 'zip_code', 'status', 'plan',
];

Deno.serve(async (req) => {
  const started = Date.now();
  const base44 = createClientFromRequest(req);
  try {
    const principal = requirePlatformAdmin(await requireAuthenticatedUser(base44));
    const body = await req.json();
    const input = body?.agencyData;
    if (!input || typeof input !== 'object' || typeof input.name !== 'string' || !input.name.trim()) {
      throw new SecurityError(400, 'invalid_agency', 'A valid agency name is required.');
    }

    const agencyData = Object.fromEntries(
      ALLOWED_AGENCY_FIELDS
        .filter((field) => input[field] !== undefined)
        .map((field) => [field, typeof input[field] === 'string' ? input[field].trim() : input[field]]),
    );
    const agency = await base44.asServiceRole.entities.Agency.create(agencyData);

    if (typeof body.owner_user_id === 'string' && body.owner_user_id) {
      await base44.asServiceRole.entities.User.update(body.owner_user_id, {
        agency_id: agency.id,
        app_role: 'agency_admin',
        membership_status: 'active',
      });
    }

    securityLog('agency.create', {
      result: 'allowed', userId: principal.id, agencyId: agency.id, durationMs: Date.now() - started,
    });
    return jsonResponse({ success: true, agency_id: agency.id }, 201);
  } catch (error) {
    securityLog('agency.create', { result: 'denied', errorCategory: 'authorization', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
