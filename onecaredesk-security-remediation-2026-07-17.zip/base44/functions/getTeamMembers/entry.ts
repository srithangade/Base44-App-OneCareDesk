import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  AGENCY_MANAGER_ROLES,
  errorResponse,
  jsonResponse,
  requireAgencyRole,
  requireAuthenticatedUser,
  securityLog,
} from '../_shared/security.ts';

Deno.serve(async (req) => {
  const started = Date.now();
  const base44 = createClientFromRequest(req);
  try {
    const principal = requireAgencyRole(await requireAuthenticatedUser(base44), AGENCY_MANAGER_ROLES);
    if (principal.isPlatformAdmin) return jsonResponse({ members: [] });
    const users = await base44.asServiceRole.entities.User.filter({ agency_id: principal.agencyId });
    const members = users.map((user: any) => ({
      id: user.id,
      full_name: user.full_name,
      email: user.email,
      app_role: user.app_role,
      agency_id: user.agency_id,
      disabled: Boolean(user.disabled),
      membership_status: user.membership_status,
      created_date: user.created_date,
    }));
    securityLog('team.list', {
      result: 'allowed', userId: principal.id, agencyId: principal.agencyId, durationMs: Date.now() - started,
    });
    return jsonResponse({ members });
  } catch (error) {
    securityLog('team.list', { result: 'denied', errorCategory: 'authorization', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
