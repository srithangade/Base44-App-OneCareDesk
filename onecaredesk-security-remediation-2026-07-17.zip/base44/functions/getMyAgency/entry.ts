import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  errorResponse,
  jsonResponse,
  requireAgencyMembership,
  requireAuthenticatedUser,
  requireRecordAccess,
  securityLog,
} from '../_shared/security.ts';

Deno.serve(async (req) => {
  const started = Date.now();
  const base44 = createClientFromRequest(req);
  try {
    const principal = requireAgencyMembership(await requireAuthenticatedUser(base44));
    if (principal.isPlatformAdmin) return jsonResponse({ agency: null });
    const agency = await base44.asServiceRole.entities.Agency.get(principal.agencyId as string);
    requireRecordAccess(principal, { ...agency, agency_id: agency.id });
    securityLog('agency.read', {
      result: 'allowed', userId: principal.id, agencyId: principal.agencyId, durationMs: Date.now() - started,
    });
    return jsonResponse({ agency });
  } catch (error) {
    securityLog('agency.read', { result: 'denied', errorCategory: 'authorization', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
