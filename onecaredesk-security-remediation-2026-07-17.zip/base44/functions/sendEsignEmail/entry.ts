import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  errorResponse,
  jsonResponse,
  requireAgencyRole,
  requireAuthenticatedUser,
  requireRecordAccess,
  securityLog,
  SecurityError,
} from '../_shared/security.ts';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const escapeHtml = (value: unknown) => String(value ?? '').replace(/[&<>'"]/g, (character) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
}[character] as string));

Deno.serve(async (req) => {
  const started = Date.now();
  const base44 = createClientFromRequest(req);
  try {
    const principal = requireAgencyRole(await requireAuthenticatedUser(base44), ['agency_admin', 'care_manager']);
    const { signatureRequestId } = await req.json();
    if (typeof signatureRequestId !== 'string' || !signatureRequestId) {
      throw new SecurityError(400, 'invalid_signature_request');
    }

    const signatureRequest = await base44.asServiceRole.entities.SignatureRequest.get(signatureRequestId);
    requireRecordAccess(principal, signatureRequest);
    const agency = await base44.asServiceRole.entities.Agency.get(signatureRequest.agency_id);

    const apiKey = Deno.env.get('RESEND_API_KEY');
    const fromEmail = Deno.env.get('RESEND_FROM_EMAIL');
    const appBaseUrl = Deno.env.get('APP_BASE_URL');
    if (!apiKey || !fromEmail || !appBaseUrl) {
      throw new SecurityError(503, 'esign_not_configured', 'E-sign email is not configured.');
    }

    const recipients = Array.isArray(signatureRequest.recipients) ? signatureRequest.recipients : [];
    if (recipients.length === 0 || recipients.length > 20 || recipients.some((recipient: any) => !EMAIL_PATTERN.test(String(recipient?.email)))) {
      throw new SecurityError(400, 'invalid_recipients');
    }

    const signatureUrl = `${appBaseUrl.replace(/\/$/, '')}/FormViewer?requestId=${encodeURIComponent(signatureRequestId)}`;
    const agencyName = escapeHtml(agency.display_name || agency.name || 'OneCareDesk');
    const title = escapeHtml(signatureRequest.title || 'Document signature request');
    const customMessage = escapeHtml(signatureRequest.custom_message || 'Please review the document.');

    for (const recipient of recipients) {
      const html = `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto">
        <h1>${agencyName}</h1>
        <p>Hello ${escapeHtml(recipient.name || 'there')},</p>
        <p>You have a document to review: <strong>${title}</strong>.</p>
        <p>${customMessage}</p>
        <p><a href="${signatureUrl}">Open the authenticated document viewer</a></p>
        <p>This development prototype is not verified for HIPAA compliance. Do not use it for real protected health information.</p>
      </div>`;
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: `${agency.display_name || agency.name || 'OneCareDesk'} <${fromEmail}>`,
          to: [recipient.email],
          subject: `Document review requested: ${signatureRequest.title || 'Untitled document'}`.slice(0, 200),
          html,
        }),
      });
      if (!response.ok) throw new Error('email_provider_error');
    }

    await base44.asServiceRole.entities.SignatureRequest.update(signatureRequestId, {
      status: 'sent',
      sent_date: new Date().toISOString(),
      signature_url: signatureUrl,
    });
    securityLog('signature_request.send', {
      result: 'allowed', userId: principal.id, agencyId: principal.agencyId, durationMs: Date.now() - started,
    });
    return jsonResponse({ success: true, sentCount: recipients.length });
  } catch (error) {
    securityLog('signature_request.send', { result: 'failed', errorCategory: 'esign', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
