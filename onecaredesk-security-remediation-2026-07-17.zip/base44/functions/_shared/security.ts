export const PLATFORM_ROLE = 'platform_admin';
export const AGENCY_ROLES = ['agency_admin', 'care_manager', 'caregiver', 'read_only'] as const;
export const AGENCY_MANAGER_ROLES = ['agency_admin', 'care_manager'] as const;

export class SecurityError extends Error {
  status: number;
  category: string;

  constructor(status: number, category: string, message = 'Access denied.') {
    super(message);
    this.name = 'SecurityError';
    this.status = status;
    this.category = category;
  }
}

export type Principal = {
  id: string;
  email: string;
  agencyId: string | null;
  appRole: string;
  isPlatformAdmin: boolean;
};

export const redactIdentifier = (value: unknown) => {
  if (typeof value !== 'string' || value.length === 0) return 'none';
  if (value.length <= 8) return 'redacted';
  return `${value.slice(0, 4)}...${value.slice(-4)}`;
};

export const securityLog = (event: string, fields: Record<string, unknown> = {}) => {
  const allowed = {
    event,
    result: fields.result || 'unknown',
    request_id: fields.requestId || 'none',
    user_id: redactIdentifier(fields.userId),
    agency_id: redactIdentifier(fields.agencyId),
    error_category: fields.errorCategory || 'none',
    duration_ms: typeof fields.durationMs === 'number' ? fields.durationMs : undefined,
  };
  console.info(JSON.stringify(allowed));
};

export async function requireAuthenticatedUser(base44: any): Promise<Principal> {
  let user;
  try {
    user = await base44.auth.me();
  } catch {
    throw new SecurityError(401, 'unauthenticated', 'Authentication required.');
  }

  if (!user?.id || !user?.email || user.disabled === true) {
    throw new SecurityError(403, 'account_unavailable');
  }

  const isPlatformAdmin = user.role === 'admin';
  if (!isPlatformAdmin && user.membership_status !== 'active') {
    throw new SecurityError(403, 'membership_inactive');
  }
  const appRole = isPlatformAdmin ? PLATFORM_ROLE : String(user.app_role || '');

  if (!isPlatformAdmin && !AGENCY_ROLES.includes(appRole as typeof AGENCY_ROLES[number])) {
    throw new SecurityError(403, 'role_missing');
  }

  return {
    id: user.id,
    email: user.email,
    agencyId: typeof user.agency_id === 'string' && user.agency_id ? user.agency_id : null,
    appRole,
    isPlatformAdmin,
  };
}

export function requirePlatformAdmin(principal: Principal) {
  if (!principal.isPlatformAdmin) {
    throw new SecurityError(403, 'platform_admin_required');
  }
  return principal;
}

export function requireAgencyMembership(principal: Principal) {
  if (principal.isPlatformAdmin) return principal;
  if (!principal.agencyId) {
    throw new SecurityError(403, 'agency_membership_required');
  }
  return principal;
}

export function requireAgencyRole(principal: Principal, roles: readonly string[]) {
  if (principal.isPlatformAdmin) return principal;
  requireAgencyMembership(principal);
  if (!roles.includes(principal.appRole)) {
    throw new SecurityError(403, 'role_forbidden');
  }
  return principal;
}

export function getAuthorizedAgencyId(principal: Principal, requestedAgencyId?: unknown) {
  if (principal.isPlatformAdmin) {
    if (typeof requestedAgencyId !== 'string' || !requestedAgencyId) {
      throw new SecurityError(400, 'agency_required', 'A valid agency is required.');
    }
    return requestedAgencyId;
  }

  requireAgencyMembership(principal);
  if (requestedAgencyId && requestedAgencyId !== principal.agencyId) {
    throw new SecurityError(403, 'cross_tenant_forbidden');
  }
  return principal.agencyId as string;
}

export function requireRecordAccess(principal: Principal, record: any) {
  if (principal.isPlatformAdmin) return record;
  requireAgencyMembership(principal);
  if (!record || record.agency_id !== principal.agencyId) {
    throw new SecurityError(403, 'cross_tenant_forbidden');
  }
  return record;
}

export function sanitizeUserUpdates(principal: Principal, target: any, input: unknown) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new SecurityError(400, 'invalid_updates', 'Invalid update request.');
  }

  const updates = input as Record<string, unknown>;
  const safe: Record<string, unknown> = {};

  if ('role' in updates) throw new SecurityError(403, 'role_escalation_forbidden');
  if (!principal.isPlatformAdmin && 'agency_id' in updates) {
    throw new SecurityError(403, 'cross_tenant_forbidden');
  }

  if (typeof updates.full_name === 'string' && updates.full_name.trim()) {
    safe.full_name = updates.full_name.trim().slice(0, 120);
  }
  if (typeof updates.disabled === 'boolean') safe.disabled = updates.disabled;

  if (typeof updates.app_role === 'string') {
    const allowedRoles = principal.isPlatformAdmin
      ? AGENCY_ROLES
      : AGENCY_ROLES.filter((role) => role !== 'agency_admin');
    if (!allowedRoles.includes(updates.app_role as typeof AGENCY_ROLES[number])) {
      throw new SecurityError(403, 'role_escalation_forbidden');
    }
    safe.app_role = updates.app_role;
  }

  if (principal.isPlatformAdmin && typeof updates.agency_id === 'string' && updates.agency_id) {
    safe.agency_id = updates.agency_id;
  }
  if (principal.isPlatformAdmin && typeof updates.membership_status === 'string') {
    if (!['active', 'suspended', 'revoked'].includes(updates.membership_status)) {
      throw new SecurityError(400, 'invalid_membership_status');
    }
    safe.membership_status = updates.membership_status;
  }

  if (!principal.isPlatformAdmin) {
    requireRecordAccess(principal, target);
    if (target.role === 'admin' || target.app_role === 'agency_admin') {
      throw new SecurityError(403, 'privileged_target_forbidden');
    }
  }

  if (Object.keys(safe).length === 0) {
    throw new SecurityError(400, 'no_allowed_updates', 'No supported changes were provided.');
  }
  return safe;
}

export function constantTimeEqual(left: string, right: string) {
  const leftBytes = new TextEncoder().encode(left);
  const rightBytes = new TextEncoder().encode(right);
  let mismatch = leftBytes.length ^ rightBytes.length;
  const length = Math.max(leftBytes.length, rightBytes.length);
  for (let index = 0; index < length; index += 1) {
    mismatch |= (leftBytes[index] || 0) ^ (rightBytes[index] || 0);
  }
  return mismatch === 0;
}

export function requireWebhookBearerSecret(req: Request, environmentName: string) {
  const expected = Deno.env.get(environmentName);
  const header = req.headers.get('authorization') || '';
  const supplied = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!expected || !supplied || !constantTimeEqual(supplied, expected)) {
    throw new SecurityError(403, 'webhook_auth_failed');
  }
}

export function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

export function errorResponse(error: unknown) {
  if (error instanceof SecurityError) {
    return jsonResponse({ error: error.message }, error.status);
  }
  return jsonResponse({ error: 'The request could not be completed.' }, 500);
}
