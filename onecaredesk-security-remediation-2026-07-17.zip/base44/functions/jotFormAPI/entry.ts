import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  errorResponse,
  jsonResponse,
  requireAgencyRole,
  requireAuthenticatedUser,
  securityLog,
  SecurityError,
} from '../_shared/security.ts';

const ALLOWED_ACTIONS: Record<string, (body: any) => string> = {
  test: () => '/user',
  getForms: () => '/user/forms?limit=100',
  listForms: () => '/user/forms?limit=100',
  getForm: (body) => `/form/${encodeURIComponent(body.formId || '')}`,
  getSubmissions: (body) => `/form/${encodeURIComponent(body.formId || '')}/submissions?limit=100`,
};

Deno.serve(async (req) => {
  const started = Date.now();
  const base44 = createClientFromRequest(req);
  try {
    const principal = requireAgencyRole(await requireAuthenticatedUser(base44), ['agency_admin']);
    const body = await req.json();
    const buildPath = ALLOWED_ACTIONS[body?.action];
    if (!buildPath) throw new SecurityError(400, 'invalid_action', 'Unsupported Jotform action.');
    const apiKey = Deno.env.get('JOTFORM_API_KEY');
    if (!apiKey) throw new SecurityError(503, 'jotform_not_configured', 'Jotform is not configured.');

    const response = await fetch(`https://api.jotform.com${buildPath(body)}`, {
      headers: { APIKEY: apiKey },
    });
    if (!response.ok) throw new Error('jotform_provider_error');
    const data = await response.json();
    securityLog('jotform.api', {
      result: 'allowed', userId: principal.id, agencyId: principal.agencyId, durationMs: Date.now() - started,
    });
    return jsonResponse(data.content ?? data);
  } catch (error) {
    securityLog('jotform.api', { result: 'failed', errorCategory: 'jotform', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
