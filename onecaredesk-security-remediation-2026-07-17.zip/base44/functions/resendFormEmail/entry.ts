import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  errorResponse,
  jsonResponse,
  requireAgencyRole,
  requireAuthenticatedUser,
  requireRecordAccess,
  securityLog,
  SecurityError,
} from '../_shared/security.ts';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

Deno.serve(async (req) => {
  const started = Date.now();
  const base44 = createClientFromRequest(req);
  try {
    const principal = requireAgencyRole(await requireAuthenticatedUser(base44), ['agency_admin', 'care_manager']);
    const { webhookCallId } = await req.json();
    if (typeof webhookCallId !== 'string' || !webhookCallId) throw new SecurityError(400, 'invalid_submission');
    const record = await base44.asServiceRole.entities.WebhookCall.get(webhookCallId);
    requireRecordAccess(principal, record);

    const data = JSON.parse(record.body_data || '{}');
    const recipientEmail = String(data.email || '').toLowerCase();
    if (!EMAIL_PATTERN.test(recipientEmail)) throw new SecurityError(400, 'recipient_unavailable');
    const apiKey = Deno.env.get('RESEND_API_KEY');
    const fromEmail = Deno.env.get('RESEND_FROM_EMAIL');
    if (!apiKey || !fromEmail) throw new SecurityError(503, 'email_not_configured', 'Email is not configured.');

    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: `${Deno.env.get('RESEND_FROM_NAME') || 'OneCareDesk'} <${fromEmail}>`,
        to: [recipientEmail],
        subject: 'Synthetic form submission received',
        html: '<p>Your synthetic prototype form submission was received.</p><p>Do not use OneCareDesk for real protected health information.</p>',
      }),
    });
    if (!response.ok) throw new Error('email_provider_error');

    data._email_processing_result = { status: 'sent', sent_at: new Date().toISOString() };
    await base44.asServiceRole.entities.WebhookCall.update(record.id, { body_data: JSON.stringify(data) });
    securityLog('form_submission.email_resend', {
      result: 'allowed', userId: principal.id, agencyId: principal.agencyId, durationMs: Date.now() - started,
    });
    return jsonResponse({ success: true });
  } catch (error) {
    securityLog('form_submission.email_resend', { result: 'failed', errorCategory: 'email', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
