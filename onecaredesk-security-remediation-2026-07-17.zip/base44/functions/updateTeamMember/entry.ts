import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  AGENCY_MANAGER_ROLES,
  errorResponse,
  jsonResponse,
  requireAgencyRole,
  requireAuthenticatedUser,
  sanitizeUserUpdates,
  securityLog,
  SecurityError,
} from '../_shared/security.ts';

Deno.serve(async (req) => {
  const started = Date.now();
  const base44 = createClientFromRequest(req);
  try {
    const principal = requireAgencyRole(await requireAuthenticatedUser(base44), AGENCY_MANAGER_ROLES);
    const { user_id, updates } = await req.json();
    if (typeof user_id !== 'string' || !user_id) {
      throw new SecurityError(400, 'invalid_target', 'A valid user is required.');
    }

    const target = await base44.asServiceRole.entities.User.get(user_id);
    const safeUpdates = sanitizeUserUpdates(principal, target, updates);
    const updated = await base44.asServiceRole.entities.User.update(user_id, safeUpdates);
    securityLog('team.update', {
      result: 'allowed', userId: principal.id, agencyId: principal.agencyId, durationMs: Date.now() - started,
    });
    return jsonResponse({
      success: true,
      user: {
        id: updated.id,
        full_name: updated.full_name,
        email: updated.email,
        app_role: updated.app_role,
        agency_id: updated.agency_id,
        disabled: Boolean(updated.disabled),
      },
    });
  } catch (error) {
    securityLog('team.update', { result: 'denied', errorCategory: 'authorization', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
