import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  errorResponse,
  requireWebhookBearerSecret,
  securityLog,
  SecurityError,
} from '../_shared/security.ts';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

Deno.serve(async (req) => {
  const started = Date.now();
  try {
    requireWebhookBearerSecret(req, 'JOTFORM_WEBHOOK_SECRET');
    const base44 = createClientFromRequest(req);
    const contentType = req.headers.get('content-type') || '';
    const bodyText = await req.text();
    const body = contentType.includes('application/json')
      ? JSON.parse(bodyText)
      : Object.fromEntries(new URLSearchParams(bodyText).entries());

    const formId = String(body.formID || body.form_id || '');
    const submissionId = String(body.submissionID || body.submission_id || '');
    const reportId = String(body.reportid || body.report_id || '');
    const recipientEmail = String(body.submittedby || body.submitted_by || body.email || '').toLowerCase();
    if (!formId || !submissionId || !EMAIL_PATTERN.test(recipientEmail)) {
      throw new SecurityError(400, 'invalid_webhook_payload', 'Invalid submission.');
    }

    const templates = await base44.asServiceRole.entities.FormTemplate.filter({
      $or: [{ external_form_id: formId }, { jotform_form_id: formId }],
    });
    const template = templates[0];
    if (!template?.agency_id) throw new SecurityError(403, 'unmapped_form');

    const existing = await base44.asServiceRole.entities.WebhookCall.filter({
      webhook_type: 'form_submission',
      external_submission_id: submissionId,
    });
    if (existing.length > 0) {
      return new Response('Submission already processed.', { status: 200 });
    }

    const sanitized = {
      formID: formId,
      submissionID: submissionId,
      reportid: reportId || null,
      email: recipientEmail,
      _email_processing_result: { status: 'not_sent' },
    };
    await base44.asServiceRole.entities.WebhookCall.create({
      agency_id: template.agency_id,
      webhook_type: 'form_submission',
      external_submission_id: submissionId,
      form_template_id: template.id,
      body_data: JSON.stringify(sanitized),
      response_status: 200,
      processing_time_ms: Date.now() - started,
    });

    securityLog('jotform.webhook', {
      result: 'accepted', agencyId: template.agency_id, durationMs: Date.now() - started,
    });
    return new Response('<!doctype html><html><body><h1>Submission received</h1><p>You may close this window.</p></body></html>', {
      status: 200,
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    });
  } catch (error) {
    securityLog('jotform.webhook', { result: 'rejected', errorCategory: 'webhook', durationMs: Date.now() - started });
    return errorResponse(error);
  }
});
