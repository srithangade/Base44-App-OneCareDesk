import { createClientFromRequest } from 'npm:@base44/sdk@0.8.39';
import {
  errorResponse,
  jsonResponse,
  requireAuthenticatedUser,
  requirePlatformAdmin,
  securityLog,
} from '../_shared/security.ts';

Deno.serve(async (req) => {
  const started = Date.now();
  const base44 = createClientFromRequest(req);
  try {
    const principal = requirePlatformAdmin(await requireAuthenticatedUser(base44));
    const [users, agencies] = await Promise.all([
      base44.asServiceRole.entities.User.list('-created_date', 250),
      base44.asServiceRole.entities.Agency.list('-created_date', 250),
    ]);

    const safeUsers = users.map((user: any) => ({
      id: user.id,
      full_name: user.full_name,
      email: user.email,
      role: user.role,
      app_role: user.app_role,
      agency_id: user.agency_id,
      disabled: Boolean(user.disabled),
      membership_status: user.membership_status,
      created_date: user.created_date,
    }));
    const safeAgencies = agencies.map((agency: any) => ({
      id: agency.id,
      name: agency.name,
      status: agency.status,
      plan: agency.plan,
      created_date: agency.created_date,
    }));

    securityLog('platform.user_management.read', {
      result: 'allowed', userId: principal.id, durationMs: Date.now() - started,
    });
    return jsonResponse({ users: safeUsers, agencies: safeAgencies });
  } catch (error) {
    securityLog('platform.user_management.read', {
      result: 'denied', errorCategory: 'authorization', durationMs: Date.now() - started,
    });
    return errorResponse(error);
  }
});
