# Security remediation working notes

Private working note for the OneCareDesk security-remediation review. This file intentionally contains no credential values, password values, tokens, or reproduced personal identifiers.

## Scope and guardrails

- Working tree only; no Git push, commit, branch publication, Base44 deployment, or provider call was performed.
- No real healthcare data was connected.
- All demonstrations and future tests must use synthetic data.
- No HIPAA compliance or production-readiness claim is made.
- Base44 and provider configuration remains a manual, hosted integration step.

## Initial authentication and authorization map

| Flow | Initial implementation found | Security decision |
| --- | --- | --- |
| Login | Custom `auth` backend compared application-managed SHA-256 hashes using one hard-coded salt and returned an `AppUser` session object | Deleted; managed Base44 login redirect only |
| Registration | Custom account and agency bootstrap paths | Removed; use Base44 managed users and platform-admin agency creation |
| Invitations | Custom AgencyInvitation tokens, temporary passwords, and email functions | Deleted; use `base44.auth.inviteUser` and assign tenant/agency role after managed acceptance |
| Password reset/change | Custom reset token, hash write, team reset, and ChangePassword/ResetPassword pages | Deleted; use Base44 managed recovery only |
| Session creation | Serialized `app_user` placed in localStorage; some SDK token parsing duplicated in app parameters | Deleted; the Base44 SDK exclusively owns session/token state |
| Logout | Custom local object removal mixed with SDK behavior | Replaced by `base44.auth.logout()` |
| User lookup | AppUser lookups plus client-stored identity | Replaced by managed `base44.auth.me()` and narrow backend User reads |
| Role assignment | Client role fields and special-case email checks | Replaced by built-in platform admin plus server-assigned `app_role`; update allowlist blocks elevation |
| Agency assignment | Client values and localStorage used in filters and decisions | Managed User `agency_id`; backend derives tenant and entity rules enforce matching membership |
| Super-admin creation | Default/bootstrap/debug functions with privileged service-role writes | Deleted; platform administrators must be provisioned through Base44 administration |
| Team management | Custom invitation/password/reset workflow and AppUser records | Managed User list/update/delete backends with same-agency and privileged-target checks |
| Service role | Several endpoints used elevated access before reliable auth and tenant authorization | Rewritten so auth/role/record or webhook-secret checks precede the minimum operation |
| Route protection | SDK auth was inconsistently initialized; public/protected classification was mixed with custom state | Central managed `AuthContext`, explicit public route allowlist, protected layout redirect |
| Entity access | Client filters were treated as tenant isolation; no checked-in entity rules | Added agency entity definitions and disabled legacy credential/config entities |

## Critical findings confirmed

1. Application-managed SHA-256 password verification with one hard-coded salt.
2. Password hashes and sensitive authentication values passed through debug/error paths.
3. Custom password reset, invitation, temporary password, and session lifecycle.
4. Authentication, role, and tenant decisions derived from a mutable `localStorage.app_user` object.
5. Service-role operations with inadequate authentication, authorization, record ownership, or response minimization.
6. Client-provided `agency_id` accepted in privileged flows.
7. Default credential, emergency login, debug login, super-admin bootstrap, and password-fix utilities.
8. Provider credentials represented in a client-readable Configuration workflow.
9. Public webhooks that trusted payload data and logged full requests.
10. Realistic health-related sample records and hard-coded contact/admin identifiers in the current tree and Git history.
11. Marketing language that could be interpreted as a HIPAA-compliance claim.
12. No meaningful README, threat model, privacy limitations, or security regression suite.

## Auth migration implemented

- `src/lib/AuthContext.jsx` uses `base44.auth.isAuthenticated`, `base44.auth.me`, `base44.auth.redirectToLogin`, and `base44.auth.logout`.
- `src/pages/Auth.jsx` contains no password fields and redirects to Base44's hosted login.
- `src/Layout.jsx`, `src/components/layouts/ProtectedLayout.jsx`, and `src/lib/routeAccess.js` establish the route boundary.
- `src/lib/app-params.js` no longer reads, stores, or forwards a custom token.
- Custom login, password, reset, verification, invitation acceptance, recovery, and change-password code was removed.
- Existing password hashes are not and must not be migrated. Existing custom sessions are intentionally invalid.
- Synthetic test accounts must be re-invited or recover access through Base44 managed flows.

## Authorization model implemented

`base44/functions/_shared/security.ts` is the common authorization boundary. It resolves the managed User, treats only the built-in Base44 `role === "admin"` as platform admin, validates agency membership and application role, rejects tenant overrides, checks record ownership, allowlists User updates, emits redacted logs, and produces generic errors.

User membership fields in `base44/entities/User.jsonc` are client-write-disabled. Agency-owned entity definitions require an agency and specify record rules. Legacy credential/config/invitation/role/test entities are denied all direct operations.

Client entity filters remain for correct UX but are not treated as authorization.

## Service-role review

| Function | Guard before service role | Minimum operation |
| --- | --- | --- |
| `createAgency` | Managed user plus built-in platform admin | Create one agency; optionally assign an existing managed owner |
| `getUserManagementData` | Managed user plus built-in platform admin | Narrow User and Agency lists |
| `getTeamMembers` | Managed agency manager role | List Users from the caller's agency |
| `updateTeamMember` | Managed agency manager role, same-agency target, update allowlist | Update one managed User |
| `deleteTeamMember` | Managed agency manager role, same-agency non-privileged target | Revoke and disable one managed User without deleting the identity |
| `getMyAgency` | Managed agency membership | Read the caller's agency |
| `sendEsignEmail` | Managed agency manager role plus signature-record ownership | Read one request/agency, send, update one request |
| `resendFormEmail` | Managed agency manager role plus webhook-record ownership | Read/update one submission metadata record |
| `formSubmissionHandler` | Jotform bearer secret plus server-side form-to-agency mapping | Dedupe and create minimized submission metadata |
| `boldSignWebhook` | BoldSign bearer secret plus known document mapping | Update status on one known signature request |

The local test suite statically fails if a new function contains `asServiceRole` without an authentication or webhook-secret guard appearing first. Hosted behavioral tests are still required.

## Dangerous functions and UI removed

Backend entries removed:

- `acceptAgencyInvitation`, `auth`, `basicPlatformTest`, `createSuperAdmin`
- `debugAgencyCreation`, `debugAuth`, `debugLogin`, `emergencyLogin`
- `fixAdminUser`, `fixPassword`, `initializeSuperAdmin`
- `inviteTeamMember`, `requestPasswordReset`, `requestUsernameRecovery`
- `resendInvitationEmail`, `resetPassword`, `resetTeamMemberPassword`
- `sendAgencyInvitation`, `testFunction`, `webhookTest`
- Duplicate/unsafe `formHandler`, `formReceiver`, obsolete `getFormSubmission`, and unused generic `sendEmail`

Frontend auth/debug/integration surfaces removed include custom password and invitation pages, BoldSign callback and integration test pages, webhook debug viewers, the old AuthWrapper, custom security utility, client email/e-sign provider wrappers, and the former API-key settings flow.

## Logging changes

- Removed all `console.*` use from `src`.
- Removed raw request, response, credential, record, user, appointment, submission, and signature logging.
- Backend functions call only the allowlisted `securityLog` serializer.
- Allowed fields are event, result, request ID, redacted user ID, redacted agency ID, error category, and duration.
- Unexpected failures return a generic response. Removed account-recovery endpoints cannot disclose account existence.

## Healthcare-data changes

- Added the exact prototype/HIPAA warning globally and in documentation.
- Replaced realistic lead test data and health notes with one explicitly synthetic reserved-domain sample.
- Disabled public contact and trial-request collection; those pages send and retain nothing.
- Minimized stored Jotform webhook metadata and removed raw-payload presentation/logging.
- Removed unsupported compliance claims from marketing UI.

## Secret and history scan

Current tree scan:

- No `.env`, certificate, private-key, or credential file is tracked.
- No provider API-key value, service-role credential, bearer token, custom password hash, hard-coded salt, or default password remains in application source.
- Backend secret names appear only as environment lookups and documentation.
- Current email/phone literals are reserved synthetic examples in tests/demo input; dependency metadata may contain package-maintainer information.
- `gitleaks` was not installed, so the scan used targeted current-tree and all-commit Git searches. A dedicated secret-scanning tool should still run before publication.

Git history scan across seven commits found the deleted custom credential system, default/bootstrap credential logic, hard-coded administrator/contact identifiers, realistic synthetic health-related examples, and custom invitation/reset code. No external provider API-key value was identified by the targeted patterns. Because deletion from the working tree does not rewrite history:

- Treat every historical default/custom credential as exposed and invalid.
- Revoke old custom sessions and remove old credential-bearing entity data under an approved procedure.
- Rotate any account credential that was ever reused outside the prototype.
- Review whether historical personal identifiers require removal.
- Use an approved history-rewrite process only after owner coordination; then force-update branches/tags and require fresh clones.

## Local security tests

`npm.cmd test` currently executes 18 passing tests across two files. Coverage includes unauthenticated and inactive-membership rejection before elevated access, cross-tenant record rejection for read/update/delete, client tenant override rejection, localStorage tampering irrelevance, regular and agency-admin escalation rejection, managed platform-admin derivation, role gates, generic errors, log redaction, custom-auth regression scans, protected-route classification, reserved synthetic contact literals, and service-role guard ordering.

The following are intentionally not claimed as local passes: Base44 invitation single-use, expiry, revocation, and intended-email binding; managed password recovery/session revocation; hosted entity-rule enforcement; and provider callback behavior. These require a dedicated hosted Base44 test app.

## Validation record

- Install: passed via `npm.cmd install` on Windows PowerShell.
- Lint: passed, `npm.cmd run lint`.
- Typecheck: failed, `npm.cmd run typecheck`, with 943 errors across 71 files. The existing `checkJs` configuration infers incompatible props for the generated JavaScript UI primitives and cannot resolve Base44 Vite virtual modules under standalone `tsc`. The production build succeeds. The typecheck was not weakened or relabeled as passing.
- Build: passed, `npm.cmd run build`; warnings note missing local Base44 proxy configuration and stale browser-compatibility metadata.
- Tests: passed, 2 files and 18 tests.
- Dependency audit: passed with 0 known vulnerabilities after a non-forced audit update and removal of unused `jspdf`, `lodash`, and `react-quill` packages. No `--force` was used.

## Manual Base44 configuration and test checklist

1. Create or select a dedicated non-production Base44 app containing synthetic data only.
2. Configure email/password managed authentication from `base44/auth/config.jsonc`; decide registration visibility in the Base44 dashboard; keep social providers disabled unless separately reviewed.
3. Pull the linked non-production app's current entity schemas and back them up. Merge every existing field and validation rule with the checked-in definitions; the original repository did not include the remote schemas, so the agency entity files contain only the security-critical field and rule additions and must not blindly replace a richer schema.
4. Apply the merged `User.jsonc` custom fields and entity definitions after review. Verify ordinary users cannot write `agency_id`, `app_role`, or `membership_status`; confirm each agency entity requires `agency_id`; confirm Agency is direct-admin-only; confirm AppUser, Configuration, AgencyInvitation, RoleAssignment, and WebhookTest are denied.
5. Deploy backend functions only after review. Configure `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, optional `RESEND_FROM_NAME`, `APP_BASE_URL`, `JOTFORM_API_KEY`, `JOTFORM_WEBHOOK_SECRET`, and `BOLDSIGN_WEBHOOK_SECRET` in the Base44 function secret store. Do not use client-prefixed variables.
6. Disable Jotform/BoldSign callbacks until the provider is configured to deliver the matching secret. Replace the BoldSign bearer gate with verified provider-native signing when its current contract is confirmed.
7. Provision the first platform administrator through Base44 administration. Never recreate a bootstrap endpoint or hard-coded privileged email.
8. Re-invite synthetic test users with `base44.auth.inviteUser` or use Base44 managed password recovery. Do not copy AppUser hashes, passwords, reset tokens, invitation tokens, or custom sessions.
9. After invite acceptance, use a verified platform administrator to assign `agency_id`, `app_role`, and active membership. Agency administrators may not create platform administrators or assign agency-admin/platform roles.
10. Revoke all custom sessions and retire/scrub legacy AppUser, Configuration, AgencyInvitation, RoleAssignment, and WebhookTest data through an approved backup-aware deletion procedure.
11. Create two synthetic agencies and distinct users. Test every entity and backend function for unauthenticated, same-tenant, cross-tenant ID, changed-body agency, changed-URL, changed-browser-state, regular-user, agency-admin, and platform-admin cases.
12. Test managed invitation acceptance once, reuse, expiry, revocation, resend, and wrong-email acceptance. Test reset token expiry/reuse, account enumeration, logout, session expiry, and administrative revocation.
13. Verify hosted logs contain only redacted allowlisted security events, including provider failures and authorization denials.
14. Confirm signature recipients can use the managed-authenticated FormViewer. If external unauthenticated recipients are required, stop and design a provider-managed, expiring, recipient-bound flow rather than bypassing auth.
15. Run an independent security and privacy review, dependency scan, secret scan, and penetration test before any publication or deployment decision.

## Completion boundary

The source remediation is suitable for continued technical review, but the hosted security architecture is not established until the manual checklist and integration tests pass. The repository is not recommended for production or healthcare data.
