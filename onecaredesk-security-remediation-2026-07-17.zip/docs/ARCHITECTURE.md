# OneCareDesk architecture

## Scope and status

This document describes the remediated working tree, not a deployed system. OneCareDesk is a synthetic-data development prototype. Base44-side settings and entity rules must be applied and integration tested before these boundaries can be considered effective in a hosted environment.

## Trust-boundary overview

```mermaid
flowchart TD
    B["Browser: React and Vite"] --> A["Base44 managed authentication"]
    A --> C["Authenticated Base44 client"]
    C --> R["Agency-scoped entities with RLS"]
    C --> F["Authorized backend functions"]
    F --> H["Managed User principal and server authorization helpers"]
    H --> S["Minimum required service-role operation"]
    S --> R
    W["External webhook provider"] --> G["Bearer-secret webhook gate"]
    G --> S
    F --> V["Email and form providers via server-held secrets"]
```

The browser is untrusted. URL parameters, route state, form values, `agency_id`, record IDs, and all browser storage can be changed by the caller. They are input, not proof of identity or authorization.

## Frontend

The frontend is a React 18 single-page application built by Vite. `AuthContext` asks the Base44 SDK whether a managed session exists and loads the managed current user. Public marketing routes render without an authenticated user. Every operational route is wrapped by `ProtectedLayout`, which redirects unauthenticated visitors to the Base44-hosted login flow.

The Base44 SDK exclusively owns its token and session lifecycle. The application does not copy tokens, roles, agency membership, passwords, or a custom user object to browser storage.

Client-side role checks only shape the interface. They do not establish permission.

## Managed identity and roles

The built-in Base44 User is the identity record.

- Built-in `User.role === "admin"`: platform administrator
- `User.app_role === "agency_admin"`: agency administrator
- `User.app_role === "care_manager"`: agency operations manager
- `User.app_role === "caregiver"`: limited agency worker
- `User.app_role === "read_only"`: limited read-oriented role
- `User.agency_id`: server-assigned agency membership
- `User.membership_status`: server-assigned membership state

The custom fields are defined in `base44/entities/User.jsonc` with client writes disabled for membership and roles. Platform invitations are issued through the supported Base44 invitation method. Agency assignment is performed by an authenticated platform administrator through an allowlisted backend update.

## Direct entity access

Agency-owned entity definitions require `agency_id` and specify record rules comparing `data.agency_id` to `{{user.data.agency_id}}`; the built-in platform-admin role is the explicit alternative. The direct frontend query filter is defense-in-depth and a usability optimization. The entity rule is the server-side data boundary. Because the original repository omitted the remote entity schemas, the checked-in files must be merged with schemas pulled from a linked non-production app rather than blindly replacing richer definitions.

The Agency entity itself is directly accessible only to platform administrators. Agency members retrieve their agency through `getMyAgency`, which verifies membership before the narrow service-role read.

Legacy credential-bearing entities (`AppUser`, `Configuration`, `AgencyInvitation`, `RoleAssignment`, and `WebhookTest`) have all operations disabled in the checked-in definitions and must be retired after approved data cleanup.

## Backend functions

`base44/functions/_shared/security.ts` provides the common boundary:

1. `requireAuthenticatedUser` resolves the managed Base44 principal.
2. `requirePlatformAdmin`, `requireAgencyMembership`, or `requireAgencyRole` enforces the operation-level role.
3. `getAuthorizedAgencyId` rejects tenant overrides.
4. `requireRecordAccess` verifies record ownership.
5. `sanitizeUserUpdates` permits only supported User changes and blocks elevation.
6. A service-role client performs only the minimum post-authorization read or write.
7. `securityLog` emits an allowlisted event with redacted identifiers.

Service-role access is not returned to the browser. Function responses contain narrow response objects rather than unrestricted entity records.

## Webhooks and integrations

Jotform and BoldSign webhook endpoints require an environment-held bearer secret before service-role access. Jotform tenant membership is derived from a server-side FormTemplate mapping; an agency ID in the incoming body is ignored. Raw payloads are not logged or retained. Stored submission metadata is limited to form ID, provider submission ID, report ID, recipient email used for the prototype notification, delivery status, and processing metadata.

Email and Jotform API keys are read only from the backend environment. The former client-accessible Configuration entity is disabled.

BoldSign bearer authentication is a temporary integration gate, not verified provider-native signature validation. Keep the endpoint disabled unless the provider can supply the configured header. Implement provider-native verification after confirming the current BoldSign contract.

## Security events

Structured security events allow only event name, result, request ID, redacted user ID, redacted agency ID, error category, and duration. Passwords, tokens, emails, phone numbers, records, request bodies, and medical data are not accepted by the log serializer.

The current event stream is not a complete audit system. Retention, integrity protection, access controls, alerting, time synchronization, and review procedures remain deployment requirements.

## Failure behavior

Authentication failures return `401`; authorization failures use generic `403` messages; unexpected failures return a generic `500` body. Account-discovery reset and username-recovery endpoints were removed. Provider-specific errors are not returned verbatim to clients.

## Deployment boundary

Building this repository does not configure Base44. A reviewer must apply auth configuration, User fields, entity rules, backend functions, and secrets in a dedicated synthetic-data app, then execute the integration matrix in `SECURITY_REMEDIATION_NOTES.md`. No real healthcare data may be used.
