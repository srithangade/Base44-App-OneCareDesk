# Security and privacy limitations

> OneCareDesk is a development prototype and has not been verified for HIPAA compliance or production handling of protected health information.

## Authentication status

The application code now delegates login, logout, session state, invitations, and password recovery to Base44 managed authentication. The prior custom SHA-256 password scheme and custom session object were removed. This is not proof that a hosted Base44 instance has been configured correctly. Existing custom accounts must not have their old hashes copied into Base44; synthetic test users must be re-invited or use Base44's platform-managed reset flow.

## Authorization model

Platform administration uses the built-in Base44 admin role. Agency roles and agency membership are managed User fields that application clients cannot write. Elevated backend functions resolve the managed user, enforce role and tenant membership, check record ownership, and only then use service-role access.

Authorization remains dependent on correct deployment of the checked-in User-field restrictions and entity record rules. It must be verified with hosted negative tests, including two independent synthetic agencies.

## Multi-tenancy

Agency-owned data is keyed by `agency_id`. The browser-provided tenant, record ID, URL, and state are all untrusted. Checked-in entity definitions require agency membership to match the managed User. Cross-tenant read, create, update, and delete tests must be run after deployment; local unit tests cannot prove hosted rule behavior.

## Data minimization

The prototype should contain synthetic data only. Webhook storage was reduced from raw request bodies to narrow provider metadata. Provider responses should be reviewed before new fields are stored. Form, signature, patient, caregiver, document, and appointment workflows still make it easy to enter sensitive information, so access to the test environment must be limited and visible warnings must remain.

No formal data inventory, classification standard, retention schedule, deletion SLA, legal hold process, data-subject request process, or de-identification validation exists.

## Logging

Backend security logs use an allowlist and redact user and agency identifiers. Client console debugging and raw backend payload logging were removed. This does not establish a complete audit trail. Log destination access, retention, tamper resistance, alerting, review cadence, and incident correlation are not configured in this repository.

## Encryption assumptions

This repository does not verify encryption at rest, key ownership, key rotation, backup encryption, TLS configuration, certificate lifecycle, or tenant-specific keys for Base44 or any external provider. Do not infer guarantees from SDK use. Obtain and independently review current vendor documentation and contractual commitments.

## Backups and recovery

No backup scope, retention, restore test, disaster recovery objective, regional resilience plan, or deletion propagation procedure is defined here. Production use is blocked until these are documented and tested across Base44 and all vendors.

## Auditability

The prototype records selected redacted security events but does not implement an immutable audit ledger. Administrative changes, record access, exports, provider activity, and configuration changes are not comprehensively captured or reviewed.

## Vendor dependencies

The application depends on Base44 and can optionally call Resend, Jotform, and BoldSign. Client packages include Stripe libraries, but payment readiness was not established. Each vendor requires current security, privacy, data-location, subprocessors, breach-notification, retention, deletion, availability, and contract review. A business associate agreement or other appropriate agreement must be confirmed where legally required.

Provider secrets must remain server-side. Webhook authentication must match the provider's verified current delivery contract. The BoldSign endpoint uses an explicit bearer gate only and must remain disabled if the provider cannot deliver it; provider-native signature verification is still required.

## PHI restrictions

Do not enter, upload, transmit, import, or generate real protected health information, medical records, signatures, background-check data, insurance data, or production contact data. Use synthetic accounts under reserved domains and obviously fictional records. A warning banner is intentionally displayed in the app.

## HIPAA status

OneCareDesk is not represented as HIPAA compliant. The repository does not demonstrate all administrative, physical, and technical safeguards, risk analysis, policies, workforce controls, vendor agreements, contingency procedures, or required documentation. A code review alone cannot establish compliance.

## Required independent review

Before any production or healthcare deployment, obtain at minimum:

- Independent application security review and penetration test
- Hosted Base44 configuration and tenant-isolation review
- Privacy and healthcare regulatory counsel review
- Vendor and contract assessment, including applicable agreements
- Threat-model and abuse-case review with product owners
- Secure software-development, dependency, and release controls
- Data governance, retention, backup, deletion, incident-response, and access-review programs
- Accessibility, reliability, clinical-safety, and operational validation as applicable

The current recommendation is synthetic demonstrations only.
