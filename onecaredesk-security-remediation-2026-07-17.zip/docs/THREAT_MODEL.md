# OneCareDesk threat model

## System assumptions

This threat model covers the remediated source tree. The browser, all client state, URLs, request bodies, record IDs, and webhook bodies are untrusted. Base44 managed identity, correctly deployed User-field restrictions, correctly deployed entity rules, and protected backend secrets are assumed security dependencies. Only synthetic data is permitted.

| Asset | Threat | Current mitigation | Remaining risk | Required future work |
| --- | --- | --- | --- | --- |
| Managed user account | Account takeover through weak/custom credentials or stolen session | Custom passwords and sessions removed; Base44 owns login, reset, and tokens | Hosted auth settings, MFA capability, session policy, recovery, and compromised-account response are unverified | Configure managed auth; require appropriate MFA if supported; test reset, revocation, logout, and session expiry; document response process |
| Platform role | Role escalation from agency or client input | Platform admin derives only from built-in `User.role`; User role fields are client-write-disabled; backend update allowlist | Misconfigured User schema or privileged Base44 console access could still elevate | Apply schema; test negative updates; restrict and review console administrators; alert on role changes |
| Agency records | Cross-tenant access | Agency entity rules, server-derived membership, record ownership helper, negative unit tests | Hosted RLS semantics and every entity path are not yet integration tested | Deploy to synthetic test app; run Agency A/B CRUD matrix and periodic tenant-isolation tests |
| Individual record | Insecure direct object reference through changed ID or URL | `requireRecordAccess` after service-role reads; FormViewer also relies on entity rules | Direct entity calls and new functions can regress; external recipient flow is unresolved | Add hosted IDOR tests for every entity/function and code-review checklist for new access paths |
| Service-role capability | Elevated read/write abuse | Service role appears only in backend functions after managed-auth or webhook-secret guards; narrow responses | A future function may bypass helpers; application operators retain powerful access | Add CI static gate and review; minimize functions; monitor elevated events; restrict deploy permissions |
| Logs and monitoring | Sensitive logging of passwords, tokens, contacts, or healthcare records | Raw debug logging removed; structured allowlist with redacted IDs | Provider/platform logs and stack traces are not assessed; event stream is incomplete | Review hosted logs; configure retention/access/alerts; test failure paths; prohibit raw payload telemetry |
| Invitations | Reuse, expiry bypass, revocation bypass, wrong-email acceptance | Application invitation tokens removed; Base44 invitation flow used | Platform semantics are not locally testable or hosted-tested | Test single use, expiry, revocation, email binding, resend, and role assignment against Base44 |
| Password recovery | Account enumeration or reset-token abuse | Custom reset/recovery endpoints removed; application errors are generic | Managed reset configuration and rate limiting are not verified | Test managed recovery for enumeration, rate limits, token expiry, reuse, and session revocation |
| Webhook-owned records | Forged Jotform or BoldSign events | Environment bearer gate before service role; known-form/document mapping; status allowlist; no body-supplied agency trust | Secret delivery support, replay prevention, rotation, timestamping, and provider-native signatures are incomplete | Verify provider contract; implement native signatures and replay window; rotate secrets; disable unsupported endpoint |
| Forms, documents, signatures | Unauthorized link or file exposure | Operational routes require managed auth; tenant entity rules; Jotform host allowlist and sandbox | Signature recipients may not have accounts; third-party form/file authorization and retention are unverified | Design explicit external-recipient model or keep disabled; add short-lived provider-managed access; review storage and downloads |
| Patient/caregiver information | PHI or personal-data leakage | In-app warning; synthetic-only policy; raw payload logging removed; agency boundaries | UI still accepts health-adjacent free text and files; no DLP, retention, export, or deletion control | Block real data operationally; add synthetic fixtures; implement governance only after legal/privacy design |
| Browser state | Client-side state tampering | No `app_user` session; SDK managed user is resolved; server rejects role/agency overrides | UI checks can still be bypassed and must never become authorization | Keep authorization server-side; add automated checks for browser storage and body tampering |
| Dependencies and build | Vulnerable or compromised package | Lockfile present; npm audit and build gates run | Current dependency advisories remain; no provenance/SBOM/update policy | Triage advisories, upgrade safely, add dependency review/SBOM/lockfile controls and recurring scans |
| Environment and data | Production data in a misconfigured prototype | Global warning and documentation restrict use to synthetic data | A deployer could still connect a real source or remove warnings | Separate test accounts/projects, least privilege, environment allowlist, deployment approval, and data-ingress controls |

## Abuse cases to preserve in testing

- A caller edits `agency_id` in a create or update body.
- A caller submits another agency's record ID.
- An agency administrator assigns `agency_admin`, `platform_admin`, or another agency.
- An unauthenticated caller invokes every function that uses service role.
- A webhook omits or changes its authorization secret, repeats an event, or supplies an unknown mapping.
- A user modifies browser storage to look like an administrator.
- A failure includes a real-looking email, phone number, patient object, or provider response and is observed in logs.
- An invitation is accepted twice, after expiry, after revocation, or by another email.

The invitation cases and hosted Base44 entity enforcement require integration tests; the local suite deliberately does not label them as passed.
