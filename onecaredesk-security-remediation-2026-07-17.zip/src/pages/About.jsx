
import React from 'react';
import { Heart, Target, Award, Linkedin } from 'lucide-react';
import Logo from '@/components/shared/Logo'; // Added: Missing Logo Import
import PublicHeader from '@/components/shared/PublicHeader';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';

export default function About() {
  const values = [
    {
      icon: <Heart className="w-6 h-6" />,
      title: "Compassionate Care",
      description: "We believe technology should enhance, not replace, the human touch in healthcare."
    },
    {
      icon: <Target className="w-6 h-6" />,
      title: "Mission-Driven",
      description: "Our mission is to empower home care agencies to provide better care while growing sustainably."
    },
    {
      icon: <Award className="w-6 h-6" />,
      title: "Excellence",
      description: "We strive for excellence in every feature, every interaction, and every customer relationship."
    }
  ];

  const teamMembers = [
    {
      name: "Ravinder Gade",
      role: "Founder & CEO",
      image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68a14f94b8d5485bd1383f1e/a1b9a2086_1685484875581.jpg",
      bio: "Visionary entrepreneur and technology leader with extensive experience in healthcare solutions and business innovation.",
      linkedin: "https://www.linkedin.com/in/ravindergade"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <PublicHeader />
      
      <main className="pt-20">
        {/* Hero Section */}
        <section className="bg-white py-16 sm:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl">
                About OneCareDesk
              </h1>
              <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
                We're on a mission to transform home care through innovative technology, 
                empowering agencies to provide better care while growing their business.
              </p>
            </div>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-16 sm:py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-extrabold text-gray-900">Our Story</h2>
                <div className="mt-6 text-lg text-gray-600 space-y-4">
                  <p>
                    OneCareDesk was founded by Ravinder Gade, a visionary entrepreneur 
                    who recognized the massive potential for technology to transform 
                    the home care industry. With deep experience in healthcare solutions 
                    and business innovation, Ravinder saw firsthand the challenges 
                    agencies face with disconnected systems and complex workflows.
                  </p>
                  <p>
                    Driven by a mission to simplify operations and improve care quality, 
                    Ravinder assembled a team of healthcare technology experts to create 
                    a comprehensive platform that addresses every aspect of home care 
                    management - from client onboarding to caregiver scheduling.
                  </p>
                  <p>
                    Today, OneCareDesk empowers agencies to focus on what matters most: 
                    providing exceptional care while building sustainable, profitable 
                    businesses that make a real difference in their communities.
                  </p>
                </div>
              </div>
              <div className="relative">
                <img
                  className="rounded-lg shadow-lg"
                  src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?q=80&w=600&h=400&fit=crop"
                  alt="Healthcare technology innovation"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-16 sm:py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900">Our Values</h2>
              <p className="mt-4 text-lg text-gray-600">
                The principles that guide everything we do
              </p>
            </div>
            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
              {values.map((value, index) => (
                <div key={index} className="text-center">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-sky-500 text-white mx-auto">
                    {value.icon}
                  </div>
                  <h3 className="mt-6 text-lg font-medium text-gray-900">{value.title}</h3>
                  <p className="mt-2 text-gray-600">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-16 sm:py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900">Meet Our Founder</h2>
              <p className="mt-4 text-lg text-gray-600">
                Leading the transformation of home care through innovative technology
              </p>
            </div>
            <div className="mt-16 flex justify-center">
              <div className="max-w-md">
                {teamMembers.map((member, index) => (
                  <div key={index} className="text-center bg-white rounded-lg shadow-lg p-8">
                    <img
                      className="w-32 h-32 rounded-full mx-auto mb-6 object-cover"
                      src={member.image}
                      alt={member.name}
                    />
                    <h3 className="text-2xl font-bold text-gray-900">{member.name}</h3>
                    <p className="text-sky-600 font-medium text-lg mb-4">{member.role}</p>
                    <p className="text-gray-600 mb-6">{member.bio}</p>
                    <a
                      href={member.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium"
                    >
                      <Linkedin className="w-5 h-5" />
                      Connect on LinkedIn
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-sky-700">
          <div className="max-w-4xl mx-auto text-center py-16 px-4 sm:py-20 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
              Ready to join our mission?
            </h2>
            <p className="mt-4 text-lg leading-6 text-sky-100">
              Let's work together to transform home care in your community.
            </p>
            <Button size="lg" className="mt-8 bg-white text-sky-700 hover:bg-sky-50" asChild>
              <Link to={createPageUrl('Contact')}>Get Started Today</Link>
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
            <div className="col-span-2 md:col-span-4 lg:col-span-1">
              <Logo size="medium" showSubtitle={false} />
              <p className="mt-4 text-sm text-slate-400">The OS for Home Care.</p>
            </div>
            <div>
              <h3 className="text-sm font-semibold tracking-wider uppercase text-slate-300">Product</h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li><Link to={createPageUrl('Features')} className="text-slate-400 hover:text-white">Features</Link></li>
                <li><Link to={createPageUrl('Pricing')} className="text-slate-400 hover:text-white">Pricing</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold tracking-wider uppercase text-slate-300">Company</h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li><Link to={createPageUrl('About')} className="text-slate-400 hover:text-white">About</Link></li>
                <li><Link to={createPageUrl('Contact')} className="text-slate-400 hover:text-white">Contact</Link></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 border-t border-slate-700 pt-8 text-center">
            <p className="text-sm text-slate-400">&copy; {new Date().getFullYear()} OneCareDesk. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
