import React from 'react';
import PublicHeader from '@/components/shared/PublicHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function Contact() {
  return (
    <div className="min-h-screen bg-slate-50">
      <PublicHeader />
      <main className="mx-auto max-w-3xl px-6 py-24">
        <Card>
          <CardHeader>
            <CardTitle>Contact workflow disabled in this prototype</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-slate-600">
            <p>This public demo does not collect, send, or retain contact details.</p>
            <p>Do not enter real personal, healthcare, or business information into this development prototype.</p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
