
import React from 'react';
import {
  ArrowRight,
  Users,
  FileText,
  Shield,
  TrendingUp,
  CheckCircle
} from 'lucide-react';
import PublicHeader from '@/components/shared/PublicHeader';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';

export default function Features() {
  const features = [
    {
      category: "Lead Management",
      title: "Turn Every Inquiry Into an Admission",
      description: "Our intuitive lead management system helps you track inquiries from first contact to admission, ensuring no opportunity is missed.",
      features: [
        "Automated lead capture from web forms and calls",
        "Visual pipeline to track lead stages",
        "Follow-up reminders and task automation",
        "Family communication log",
        "In-depth analytics on conversion rates",
      ],
      icon: TrendingUp,
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop"
    },
    {
      category: "Patient & Caregiver Profiles",
      title: "Holistic Care and Staff Management",
      description: "Create detailed profiles for patients and caregivers to ensure perfect matches, personalized care, and efficient staff management.",
      features: [
        "Comprehensive patient profiles & care plans",
        "Medication and appointment tracking",
        "Caregiver skill and availability matching",
        "Certification and compliance tracking",
        "Secure internal messaging",
      ],
      icon: Users,
      image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?q=80&w=2070&auto=format&fit=crop"
    },
    {
      category: "Digital Documentation & eSign",
      title: "Go Paperless with Confidence",
      description: "Explore prototype digital-form and e-signature workflows using synthetic data only.",
      features: [
        "Customizable form and document builder",
        "Secure e-signature workflows (BoldSign, etc.)",
        "Centralized document repository",
        "Automated reminders for expiring documents",
        "Version control and audit trails",
      ],
      icon: FileText,
      image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?q=80&w=2070&auto=format&fit=crop"
    },
    {
      category: "Scheduling & Compliance",
      title: "Simplify Scheduling, Ensure Compliance",
      description: "Our powerful scheduling engine makes it easy to manage shifts and visits, while built-in compliance checks give you peace of mind.",
      features: [
        "Drag-and-drop calendar interface",
        "Automated shift reminders for caregivers",
        "Mobile access to schedules and visit notes",
        "Prototype validation checks",
        "Time tracking and visit verification",
      ],
      icon: Shield,
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?q=80&w=2039&auto=format&fit=crop"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <PublicHeader />

      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-20 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 leading-tight mb-8">
              A Smarter Way to
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600">Manage Home Care</span>
            </h1>
            <p className="text-xl text-gray-700 mb-10 leading-relaxed">
              Discover the tools designed to help your agency operate more efficiently, so you can focus on delivering exceptional care.
            </p>
            <Button asChild size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700 shadow-lg hover:shadow-xl">
              <Link to={createPageUrl('TrialRequest')}>
                Start Free Trial <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 px-6">
          <div className="max-w-7xl mx-auto space-y-32">
            {features.map((feature, index) => (
              <div key={index} className={`grid md:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'md:grid-flow-col-dense' : ''}`}>
                <div className={index % 2 === 1 ? 'md:col-start-2' : ''}>
                  <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800 mb-4">
                    <feature.icon className="w-4 h-4 mr-2" />
                    {feature.category}
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">{feature.title}</h2>
                  <p className="text-xl text-gray-600 mb-8 leading-relaxed">{feature.description}</p>
                  <ul className="space-y-3">
                    {feature.features.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className={index % 2 === 1 ? 'md:col-start-1' : ''}>
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-200 to-purple-200 rounded-2xl blur-3xl opacity-20"></div>
                    <img
                      src={feature.image}
                      alt={feature.title}
                      className="rounded-2xl shadow-2xl relative z-10 w-full h-80 object-cover"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Final CTA Section */}
        <section className="bg-sky-700">
          <div className="max-w-4xl mx-auto text-center py-16 px-4 sm:py-20 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
              Ready to transform your agency?
            </h2>
            <p className="mt-4 text-lg leading-6 text-sky-100">
              Begin your journey with a no-risk, 14-day free trial and experience the difference.
            </p>
            <Button
              size="lg"
              className="mt-8 bg-white text-sky-700 hover:bg-sky-50 shadow-lg transform hover:scale-105 transition-transform"
              asChild
            >
              <Link to={createPageUrl('TrialRequest')}>
                Start Your Free Trial <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
    </div>
  );
}
