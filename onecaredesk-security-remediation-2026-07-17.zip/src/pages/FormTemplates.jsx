
import React, { useState, useEffect, useCallback } from "react";
import { FormTemplate } from "@/entities/FormTemplate";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Plus,
  ClipboardList,
  Trash2,
  Pencil,
  Eye,
  Copy,
  ExternalLink,
  DownloadCloud, // New Icon
} from "lucide-react";
import FormTemplateDialog from "@/components/forms/FormTemplateDialog";
import FormTemplatePreviewDialog from "@/components/forms/FormTemplatePreviewDialog";
import JotFormImportDialog from "@/components/forms/JotFormImportDialog"; // New Import
import { createPageUrl } from "@/utils";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function FormTemplates() {
  const [templates, setTemplates] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false); // New State
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [previewingTemplate, setPreviewingTemplate] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => setIsLoading(false));
  }, []);

  const loadTemplates = useCallback(async () => {
    if (!currentUser?.agency_id) {
        setIsLoading(false);
        return;
    }
    setIsLoading(true);
    try {
      const data = await FormTemplate.filter({ agency_id: currentUser.agency_id }, "-created_date");
      setTemplates(data);
    } catch {
    } finally {
      setIsLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    if (currentUser) {
      loadTemplates();
    }
  }, [currentUser, loadTemplates]);

  const handleOpenDialog = (template = null) => {
    setEditingTemplate(template);
    setIsDialogOpen(true);
  };

  const handlePreview = (template) => {
    setPreviewingTemplate(template);
    setIsPreviewOpen(true);
  };

  const copyPublicUrl = async (template) => {
    const publicUrl = `${window.location.origin}${createPageUrl(`FormViewer?id=${template.id}`)}`;
    try {
      await navigator.clipboard.writeText(publicUrl);
      // You could add a toast notification here
    } catch {
    }
  };

  const openInNewTab = (template) => {
    const publicUrl = `${window.location.origin}${createPageUrl(`FormViewer?id=${template.id}`)}`;
    window.open(publicUrl, '_blank');
  };

  const handleSubmit = async (formData) => {
    if (!currentUser?.agency_id) {
        throw new Error("Cannot save: No agency context.");
    }
    
    if (editingTemplate) {
      await FormTemplate.update(editingTemplate.id, formData);
    } else {
      await FormTemplate.create({ ...formData, agency_id: currentUser.agency_id });
    }
    loadTemplates();
  };

  const handleDelete = async (templateId) => {
    try {
      await FormTemplate.delete(templateId);
      loadTemplates();
    } catch {
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Form Templates</h1>
          <p className="text-gray-600">Manage embeddable forms for a branded user experience.</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setIsImportOpen(true)} disabled={!currentUser} variant="outline">
            <DownloadCloud className="w-4 h-4 mr-2" />
            Import from JotForm
          </Button>
          <Button onClick={() => handleOpenDialog()} disabled={!currentUser}>
            <Plus className="w-4 h-4 mr-2" />
            Add New Template
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array(3).fill(0).map((_, i) => (
                <div key={i} className="h-48 bg-gray-100 rounded-lg animate-pulse" />
            ))}
        </div>
      ) : templates.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed rounded-lg">
          <ClipboardList className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p className="font-medium text-gray-600 mb-2">No form templates found.</p>
          <p className="text-sm text-gray-500 mb-4">Import your forms from JotForm or create one manually.</p>
          <Button onClick={() => setIsImportOpen(true)} disabled={!currentUser}>
            <DownloadCloud className="w-4 h-4 mr-2" />
            Import from JotForm
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {templates.map((template) => {
            const publicUrl = `${window.location.origin}${createPageUrl(`FormViewer?id=${template.id}`)}`;
            
            return (
              <Card key={template.id} className="flex flex-col">
                <CardHeader>
                  <CardTitle className="truncate">{template.name}</CardTitle>
                  <CardDescription className="truncate">{template.description}</CardDescription>
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <span className="font-medium">Provider:</span>
                    <span>{template.provider}</span>
                  </div>
                </CardHeader>
                <CardContent className="flex-grow space-y-4">
                  {/* Public URL Display */}
                  <div className="bg-gray-50 p-3 rounded border">
                    <label className="text-xs font-medium text-gray-600">Public URL:</label>
                    <div className="mt-1 flex items-center gap-1">
                      <input
                        type="text"
                        value={publicUrl}
                        readOnly
                        className="flex-1 text-xs bg-white border border-gray-200 rounded px-2 py-1 font-mono text-blue-600 truncate"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => copyPublicUrl(template)}
                        className="h-7 w-7 flex-shrink-0"
                        title="Copy URL"
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
                
                {/* Action Buttons */}
                <div className="border-t p-4 flex justify-between">
                  <div className="flex gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handlePreview(template)}
                      title="Preview Form"
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => openInNewTab(template)}
                      title="Open in New Tab"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(template)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-600">
                            <Trash2 className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will permanently delete the "{template.name}" template. This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDelete(template.id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <FormTemplateDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSubmit={handleSubmit}
        template={editingTemplate}
      />

      <FormTemplatePreviewDialog
        open={isPreviewOpen}
        onOpenChange={setIsPreviewOpen}
        template={previewingTemplate}
      />

      <JotFormImportDialog
        open={isImportOpen}
        onOpenChange={setIsImportOpen}
        onImportSuccess={loadTemplates}
      />
    </div>
  );
}
