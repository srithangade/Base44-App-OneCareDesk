import React from 'react';
import { FileText } from 'lucide-react';
import SimpleFormSubmissions from '@/components/forms/SimpleFormSubmissions';

export default function SignedDocuments() {
  return (
    <div className="mx-auto max-w-7xl p-6">
      <div className="mb-6 flex items-center gap-4">
        <FileText className="h-8 w-8 text-gray-700" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Synthetic form submissions</h1>
          <p className="text-gray-600">Agency-scoped metadata received by authenticated webhook handlers.</p>
        </div>
      </div>
      <SimpleFormSubmissions />
    </div>
  );
}
