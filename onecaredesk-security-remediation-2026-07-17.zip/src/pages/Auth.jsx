import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { createPageUrl } from '@/utils';
import { useAuth } from '@/lib/AuthContext';

export default function Auth() {
  const { isAuthenticated, isLoadingAuth, navigateToLogin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoadingAuth && isAuthenticated) {
      navigate(createPageUrl('Dashboard'), { replace: true });
    }
  }, [isAuthenticated, isLoadingAuth, navigate]);

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
            <Shield className="h-6 w-6 text-blue-700" />
          </div>
          <CardTitle>Sign in to OneCareDesk</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <p className="text-sm text-slate-600">
            Authentication, registration, invitations, password resets, and sessions are managed by Base44.
          </p>
          <Button
            className="w-full"
            disabled={isLoadingAuth}
            onClick={() => navigateToLogin(window.location.origin + createPageUrl('Dashboard'))}
          >
            <LogIn className="mr-2 h-4 w-4" />
            Continue to managed sign in
          </Button>
          <p className="text-xs text-slate-500">
            Use the Forgot password option on the Base44 sign-in screen. Existing legacy OneCareDesk passwords are not migrated.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
