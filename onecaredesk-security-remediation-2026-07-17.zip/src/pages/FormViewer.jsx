import React, { useEffect, useState } from 'react';
import { SignatureRequest } from '@/entities/SignatureRequest';
import { FormTemplate } from '@/entities/FormTemplate';
import { AlertCircle, FileSignature, Loader2 } from 'lucide-react';

const trustedJotFormUrl = (candidate) => {
  try {
    const url = new URL(candidate);
    if (url.protocol !== 'https:' || url.hostname !== 'form.jotform.com') return '';
    if (!/^\/\d+\/?$/.test(url.pathname)) return '';
    return url.toString();
  } catch {
    return '';
  }
};

export default function FormViewer() {
  const [formUrl, setFormUrl] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [signatureRequest, setSignatureRequest] = useState(null);

  useEffect(() => {
    const loadForm = async () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const requestId = params.get('requestId');
        const formId = params.get('formId');
        let resolvedFormUrl = '';

        if (requestId) {
          const request = await SignatureRequest.get(requestId);
          if (!request) throw new Error('not_found');
          setSignatureRequest(request);

          if (request.provider === 'jotform' && /^\d+$/.test(request.external_request_id || '')) {
            resolvedFormUrl = trustedJotFormUrl(`https://form.jotform.com/${request.external_request_id}`);
          } else if (request.form_template_id) {
            const template = await FormTemplate.get(request.form_template_id);
            resolvedFormUrl = trustedJotFormUrl(template?.form_url || '');
          }
        } else if (formId) {
          if (/^\d+$/.test(formId)) {
            resolvedFormUrl = trustedJotFormUrl(`https://form.jotform.com/${formId}`);
          } else {
            const template = await FormTemplate.get(formId);
            resolvedFormUrl = trustedJotFormUrl(template?.form_url || '');
          }
        }

        if (!resolvedFormUrl) throw new Error('invalid_form');
        setFormUrl(resolvedFormUrl);
      } catch {
        setError('The requested form is unavailable or you do not have access.');
      } finally {
        setIsLoading(false);
      }
    };

    loadForm();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-800">Loading form</h2>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="bg-white rounded-lg shadow p-8 text-center max-w-md">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-red-800 mb-4">Form not available</h2>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {signatureRequest && (
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="max-w-4xl mx-auto flex items-center gap-3">
            <FileSignature className="w-6 h-6 text-blue-600" />
            <div>
              <h1 className="text-lg font-semibold text-gray-900">{signatureRequest.title}</h1>
              {signatureRequest.custom_message && (
                <p className="text-sm text-gray-600">{signatureRequest.custom_message}</p>
              )}
            </div>
          </div>
        </div>
      )}
      <div className="p-4">
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-sm overflow-hidden">
          <iframe
            src={formUrl}
            width="100%"
            height="800"
            sandbox="allow-forms allow-scripts allow-same-origin"
            referrerPolicy="no-referrer"
            style={{ minHeight: '800px', border: 'none' }}
            title="JotForm"
          />
        </div>
      </div>
    </div>
  );
}
