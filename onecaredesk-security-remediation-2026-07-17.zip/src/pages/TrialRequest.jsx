import React from 'react';
import PublicHeader from '@/components/shared/PublicHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function TrialRequest() {
  return (
    <div className="min-h-screen bg-slate-50">
      <PublicHeader />
      <main className="mx-auto max-w-3xl px-6 py-24">
        <Card>
          <CardHeader>
            <CardTitle>Trial requests are disabled</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-slate-600">
            <p>This repository is available for synthetic-data technical review only. It does not provision trial accounts.</p>
            <p>Use the Base44-managed invitation flow in a dedicated non-production test app for authorized reviewers.</p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
