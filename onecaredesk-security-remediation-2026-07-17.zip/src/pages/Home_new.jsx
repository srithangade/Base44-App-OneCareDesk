
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import PublicHeader from '@/components/shared/PublicHeader';
import Logo from '@/components/shared/Logo';
import {
  Users,
  Calendar,
  DollarSign,
  ShieldCheck,
  Smartphone,
  BarChart2,
  Facebook,
  Twitter,
  Linkedin
} from 'lucide-react';
import { Link } from 'react-router-dom';
import TypingEffect from '@/components/home/TypingEffect';

const Feature = ({ icon, title, description }) => (
  <div className="text-center p-6 bg-white rounded-lg shadow-sm hover:shadow-lg transition-shadow duration-300">
    <div className="flex items-center justify-center h-12 w-12 rounded-full bg-sky-100 text-sky-600 mb-4 mx-auto">
      {icon}
    </div>
    <h3 className="text-lg font-bold text-gray-900">{title}</h3>
    <p className="mt-2 text-base text-gray-600">{description}</p>
    <a href="#" className="mt-4 inline-block text-sm font-semibold text-sky-600 hover:text-sky-800">
      Learn more &rarr;
    </a>
  </div>
);

export default function Home_new() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const dashboardImages = [
    {
      src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68a14f94b8d5485bd1383f1e/9089f2ebf_OneCareDesk-09-11-2025_05_38_AM.png",
      alt: "OneCareDesk Platform Features",
      label: "Complete Platform"
    },
    {
      src: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=800&h=400&fit=crop",
      alt: "Analytics Dashboard Interface",
      label: "Analytics Dashboard"
    },
    {
      src: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=800&h=400&fit=crop",
      alt: "Business Management Application",
      label: "Client Management"
    },
    {
      src: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?q=80&w=800&h=400&fit=crop",
      alt: "Scheduling Application Interface",
      label: "Smart Scheduling"
    },
    {
      src: "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?q=80&w=800&h=400&fit=crop",
      alt: "Digital Document Management System",
      label: "Digital Documents"
    }
  ];

  // Auto-scroll through images
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImageIndex(prevIndex => (prevIndex + 1) % dashboardImages.length);
    }, 4000); // Change image every 4 seconds
    return () => clearInterval(timer);
  }, [dashboardImages.length]);
  
  const features = [
    {
      icon: <Users className="w-6 h-6" />,
      title: "Client Management",
      description: "Keep track of all client information, care plans, and history in one secure place."
    },
    {
      icon: <Calendar className="w-6 h-6" />,
      title: "Scheduling",
      description: "Easily create, manage, and optimize caregiver schedules with our intuitive calendar."
    },
    {
      icon: <DollarSign className="w-6 h-6" />,
      title: "Billing & Payroll",
      description: "Streamline your financial workflows with automated invoicing and payroll processing."
    },
    {
      icon: <ShieldCheck className="w-6 h-6" />,
      title: "Compliance",
      description: "Stay compliant with state regulations with automated tracking and reporting."
    },
    {
      icon: <Smartphone className="w-6 h-6" />,
      title: "Caregiver Portal",
      description: "Empower your caregivers with a mobile app to view schedules, tasks, and client info."
    },
    {
      icon: <BarChart2 className="w-6 h-6" />,
      title: "Reporting",
      description: "Gain insights into your agency's performance with customizable reports and dashboards."
    }
  ];

  const heroPhrases = [
    "Streamline Your Agency.",
    "Empower Your Caregivers.",
    "Simplify Your Operations.",
    "Automate Billing.",
    "Ensure Compliance."
  ];

  return (
    <div className="bg-gray-50">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Caveat:wght@400;700&family=Kalam:wght@400;700&display=swap');
        .font-handwritten {
          font-family: 'Caveat', cursive;
        }
        .font-handwritten-bold {
          font-family: 'Kalam', cursive;
        }
        
        @keyframes circle-draw {
          0% {
            stroke-dasharray: 0 100;
          }
          100% {
            stroke-dasharray: 100 0;
          }
        }
        
        @keyframes highlight-draw {
          0% {
            stroke-dasharray: 0 200;
          }
          100% {
            stroke-dasharray: 200 0;
          }
        }
        
        .circle-highlight {
          animation: circle-draw 2s ease-in-out infinite alternate;
        }
        
        .underline-highlight {
          animation: highlight-draw 2s ease-in-out infinite alternate;
        }
        
        .floating {
          animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }

        .gradient-text {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
      `}</style>

      {/* Header - Made it more sticky/fixed */}
      <PublicHeader />

      <main className="pt-20"> {/* Added padding-top to account for fixed header */}
        {/* NEW Hero Section */}
        <section className="bg-white relative overflow-hidden">
            {/* Background decorative elements */}
            <div className="absolute top-20 left-10 w-32 h-32 bg-sky-100 rounded-full opacity-20 floating"></div>
            <div className="absolute bottom-20 left-20 w-24 h-24 bg-indigo-100 rounded-full opacity-30 floating" style={{animationDelay: '1s'}}></div>
            
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28">
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                    {/* Left Column: Enhanced Slogan with Handwritten Highlights */}
                    <div className="text-center lg:text-left relative">
                        <div className="relative mb-6">
                          <span className="font-handwritten text-2xl text-sky-600 absolute -top-8 -left-4 transform -rotate-12">
                            The future is here!
                          </span>
                          <svg className="absolute -top-6 -left-2 w-24 h-8" viewBox="0 0 100 30">
                            <path d="M10,20 Q50,5 90,20" stroke="#0EA5E9" strokeWidth="2" fill="none" className="circle-highlight" />
                          </svg>
                        </div>
                        
                        <div className="h-20 relative mb-8">
                          <TypingEffect phrases={heroPhrases} className="text-4xl lg:text-6xl font-extrabold gradient-text tracking-tight" />
                          <svg className="absolute bottom-0 left-0 w-full h-4" viewBox="0 0 400 20">
                            <path d="M5,15 Q200,5 395,15" stroke="#F59E0B" strokeWidth="3" fill="none" className="underline-highlight" />
                          </svg>
                        </div>
                        
                        <div className="relative mt-12">
                          <p className="max-w-lg mx-auto lg:mx-0 text-lg text-gray-600 leading-relaxed">
                              OneCareDesk is the <span className="font-handwritten-bold text-2xl text-indigo-600">all-in-one platform</span> to manage clients, empower caregivers, and grow your agency with 
                              <span className="relative inline-block mx-2">
                                <span className="font-handwritten text-xl text-sky-600 font-bold">confidence</span>
                                <svg className="absolute -bottom-1 left-0 w-full h-3" viewBox="0 0 100 10">
                                  <ellipse cx="50" cy="5" rx="45" ry="3" stroke="#0EA5E9" strokeWidth="2" fill="none" className="circle-highlight" />
                                </svg>
                              </span>
                          </p>
                          
                          <div className="absolute -right-4 top-4 font-handwritten text-lg text-indigo-500 transform rotate-12">
                            ← Perfect!
                          </div>
                        </div>
                        
                        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                            <Button size="lg" asChild className="bg-sky-600 hover:bg-sky-700 w-full sm:w-auto shadow-lg transform hover:scale-105 transition-all">
                                <Link to={createPageUrl('TrialRequest')}>
                                  <span className="mr-2">🚀</span>
                                  Start Free Trial
                                </Link>
                            </Button>
                            <Button size="lg" variant="outline" asChild className="w-full sm:w-auto">
                                <Link to={createPageUrl('Auth')}>Sign In</Link>
                            </Button>
                        </div>
                        
                        <div className="mt-6 font-handwritten text-sm text-gray-500 italic">
                          Join 500+ agencies already using OneCareDesk ✨
                        </div>
                    </div>

                    {/* Right Column: Image Carousel with Reduced Height */}
                    <div className="relative w-full min-h-[240px] sm:min-h-[300px]">
                        {/* Background Stack Elements */}
                        <div className="absolute inset-0 bg-gradient-to-br from-indigo-100 to-indigo-200 rounded-2xl transform -rotate-6 translate-x-4 opacity-60"></div>
                        <div className="absolute inset-0 bg-gradient-to-br from-sky-100 to-sky-200 rounded-2xl transform rotate-3 -translate-y-2 opacity-70"></div>
                        <div className="absolute inset-0 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl transform -rotate-2 translate-x-2 opacity-50"></div>

                        {/* Main Image Carousel Container */}
                        <div className="relative w-full h-full overflow-hidden rounded-2xl shadow-2xl">
                          <div
                            className="flex transition-transform duration-700 ease-in-out h-full"
                            style={{ transform: `translateX(-${currentImageIndex * 100}%)` }}
                          >
                            {dashboardImages.map((image, index) => (
                              <div key={index} className="w-full flex-shrink-0 h-full">
                                <img
                                  src={image.src}
                                  alt={image.alt}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            ))}
                          </div>
                            
                          {/* Label and Pagination Dots */}
                          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent">
                              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
                                  <div className="bg-black/50 text-white px-3 py-1 rounded-full text-sm font-medium backdrop-blur-sm">
                                      {dashboardImages[currentImageIndex].label}
                                  </div>
                                  <div className="flex space-x-2">
                                        {dashboardImages.map((_, index) => (
                                            <button
                                                key={index}
                                                onClick={() => setCurrentImageIndex(index)}
                                                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                                                    index === currentImageIndex ? 'bg-white scale-125' : 'bg-white/50'
                                                }`}
                                                aria-label={`Go to slide ${index + 1}`}
                                            ></button>
                                        ))}
                                  </div>
                              </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20 sm:py-32 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="font-semibold text-sky-600">Our Features</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mt-2">Everything you need, nothing you don't.</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">Our platform is built to handle the complexities of home care, so you can focus on what matters most.</p>
            </div>
            <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {features.map((feature, index) => (
                <Feature key={index} {...feature} />
              ))}
            </div>
          </div>
        </section>

        {/* Testimonial Section */}
        <section className="py-20 sm:py-32 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="flex items-center justify-center mb-4">
              <div className="h-16 w-16 rounded-full overflow-hidden mr-4">
                  <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=2576&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Sarah Johnson" className="w-full h-full object-cover"/>
              </div>
              <div className="text-left">
                <div className="text-lg font-bold text-gray-900">Sarah Johnson</div>
                <div className="text-gray-600">Director, Sunshine Home Care</div>
              </div>
            </div>
            <blockquote className="text-2xl sm:text-3xl font-medium text-gray-900 italic">
              "OneCareDesk has transformed our agency. We're more efficient, our caregivers are happier, and we can focus on what matters most: providing excellent care to our clients."
            </blockquote>
          </div>
        </section>

        {/* Final CTA Section */}
        <section className="bg-sky-700">
          <div className="max-w-4xl mx-auto text-center py-16 px-4 sm:py-20 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
              Ready to streamline your agency?
            </h2>
            <p className="mt-4 text-lg leading-6 text-sky-100">
              Get a demo of OneCareDesk and see how you can save time and improve care.
            </p>
            <Button size="lg" className="mt-8 bg-white text-sky-700 hover:bg-sky-50" asChild>
              <Link to={createPageUrl('TrialRequest')}>Start Free Trial</Link>
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
            <div className="col-span-2 md:col-span-4 lg:col-span-1">
              <Logo size="medium" showSubtitle={false} />
              <p className="mt-4 text-sm text-slate-400">The OS for Home Care.</p>
              <div className="mt-4 flex space-x-4">
                <a href="#" className="text-slate-400 hover:text-white"><Facebook className="h-6 w-6" /></a>
                <a href="#" className="text-slate-400 hover:text-white"><Twitter className="h-6 w-6" /></a>
                <a href="#" className="text-slate-400 hover:text-white"><Linkedin className="h-6 w-6" /></a>
              </div>
            </div>
            <div>
              <h3 className="text-sm font-semibold tracking-wider uppercase text-slate-300">Product</h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li><a href="#" className="text-slate-400 hover:text-white">Features</a></li>
                <li><Link to={createPageUrl('Pricing')} className="text-slate-400 hover:text-white">Pricing</Link></li>
                <li><a href="#" className="text-slate-400 hover:text-white">Integrations</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold tracking-wider uppercase text-slate-300">Company</h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li><Link to={createPageUrl('About')} className="text-slate-400 hover:text-white">About</Link></li>
                <li><a href="#" className="text-slate-400 hover:text-white">Careers</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white">Blog</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold tracking-wider uppercase text-slate-300">Resources</h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li><a href="#" className="text-slate-400 hover:text-white">Support</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white">API Docs</a></li>
                <li><Link to={createPageUrl('Contact')} className="text-slate-400 hover:text-white">Contact Us</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold tracking-wider uppercase text-slate-300">Legal</h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li><a href="#" className="text-slate-400 hover:text-white">Privacy</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 border-t border-slate-700 pt-8 text-center">
            <p className="text-sm text-slate-400">&copy; {new Date().getFullYear()} OneCareDesk. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
