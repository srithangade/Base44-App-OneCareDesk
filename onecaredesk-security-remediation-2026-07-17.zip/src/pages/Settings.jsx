import React, { useEffect, useState } from 'react';
import { KeyRound, Settings as SettingsIcon, ShieldAlert } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function Settings() {
  const [agency, setAgency] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const response = await base44.functions.invoke('getMyAgency');
        setAgency(response.data?.agency || response.agency || null);
      } catch {
        setAgency(null);
      }
    };
    load();
  }, []);

  return (
    <div className="mx-auto max-w-4xl space-y-6 p-6">
      <h1 className="flex items-center gap-2 text-2xl font-bold"><SettingsIcon className="h-6 w-6" /> Settings</h1>
      <Alert>
        <ShieldAlert className="h-4 w-4" />
        <AlertDescription>
          This prototype no longer reads or writes API keys through browser-accessible Configuration records. Vendor credentials must be stored in Base44 backend secrets.
        </AlertDescription>
      </Alert>
      <Card>
        <CardHeader><CardTitle>Agency</CardTitle></CardHeader>
        <CardContent>
          <p className="font-medium">{agency?.name || 'No agency assigned'}</p>
          <p className="mt-1 text-sm text-slate-500">Agency membership is derived from the authenticated Base44 User record.</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><KeyRound className="h-5 w-5" /> Backend-only configuration</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm text-slate-600">
          <p>Required vendor secrets are configured with the Base44 secret manager, never in the frontend:</p>
          <code className="block rounded bg-slate-100 p-3">RESEND_API_KEY · JOTFORM_API_KEY · BOLDSIGN_API_KEY · JOTFORM_WEBHOOK_SECRET · BOLDSIGN_WEBHOOK_SECRET</code>
          <p>See the repository README and security limitations document for manual setup and integration-test requirements.</p>
        </CardContent>
      </Card>
    </div>
  );
}
