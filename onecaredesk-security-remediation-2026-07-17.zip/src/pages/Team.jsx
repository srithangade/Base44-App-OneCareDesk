import React, { useCallback, useEffect, useState } from 'react';
import { Shield, Trash2, UserCog, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { updateTeamMember } from '@/functions/updateTeamMember';
import { deleteTeamMember } from '@/functions/deleteTeamMember';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const EDITABLE_ROLES = ['care_manager', 'caregiver', 'read_only'];

export default function Team() {
  const [currentUser, setCurrentUser] = useState(null);
  const [members, setMembers] = useState([]);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(new Set());

  const loadTeam = useCallback(async () => {
    setLoading(true);
    setMessage('');
    try {
      const user = await base44.auth.me();
      if (!['agency_admin', 'care_manager'].includes(user.app_role) || !user.agency_id) {
        throw new Error('You do not have permission to manage agency users.');
      }
      setCurrentUser(user);
      const response = await base44.functions.invoke('getTeamMembers');
      setMembers(response.data?.members || response.members || []);
    } catch {
      setMessage('Team data is unavailable or you do not have permission to view it.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadTeam();
  }, [loadTeam]);

  const updateMember = async (member, updates) => {
    setProcessing((previous) => new Set(previous).add(member.id));
    setMessage('');
    try {
      await updateTeamMember({ user_id: member.id, updates });
      await loadTeam();
    } catch {
      setMessage('The team member could not be updated.');
    } finally {
      setProcessing((previous) => {
        const next = new Set(previous);
        next.delete(member.id);
        return next;
      });
    }
  };

  const removeMember = async (member) => {
    if (!window.confirm(`Revoke ${member.full_name || 'this user'} from the application?`)) return;
    setProcessing((previous) => new Set(previous).add(member.id));
    try {
      await deleteTeamMember({ user_id: member.id });
      await loadTeam();
    } catch {
      setMessage('The team member could not be removed.');
    }
  };

  return (
    <div className="mx-auto max-w-6xl space-y-6 p-6">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold"><Users className="h-6 w-6" /> Agency team</h1>
        <p className="mt-1 text-sm text-slate-600">Roles shown here come from the authenticated Base44 User record.</p>
      </div>

      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          New users must be invited by a Base44 platform administrator. OneCareDesk does not generate passwords or invitation tokens. After the invite is accepted, a platform administrator assigns the agency and initial role.
        </AlertDescription>
      </Alert>

      {message && <Alert variant="destructive"><AlertDescription>{message}</AlertDescription></Alert>}

      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><UserCog className="h-5 w-5" /> Members</CardTitle></CardHeader>
        <CardContent>
          {loading ? <p>Loading team…</p> : (
            <Table>
              <TableHeader>
                <TableRow><TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Role</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {members.map((member) => {
                  const canManage = currentUser?.app_role === 'agency_admin' && member.id !== currentUser.id && member.app_role !== 'agency_admin';
                  return (
                    <TableRow key={member.id}>
                      <TableCell>{member.full_name || 'Unnamed user'}</TableCell>
                      <TableCell>{member.email}</TableCell>
                      <TableCell>
                        {canManage ? (
                          <Select value={member.app_role || 'read_only'} onValueChange={(app_role) => updateMember(member, { app_role })}>
                            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                            <SelectContent>{EDITABLE_ROLES.map((role) => <SelectItem key={role} value={role}>{role.replace('_', ' ')}</SelectItem>)}</SelectContent>
                          </Select>
                        ) : <Badge variant="outline">{member.app_role || 'unassigned'}</Badge>}
                      </TableCell>
                      <TableCell><Badge variant={member.disabled ? 'secondary' : 'default'}>{member.disabled ? 'disabled' : 'active'}</Badge></TableCell>
                      <TableCell className="space-x-2 text-right">
                        {canManage && (
                          <>
                            <Button size="sm" variant="outline" disabled={processing.has(member.id)} onClick={() => updateMember(member, { disabled: !member.disabled })}>
                              {member.disabled ? 'Enable' : 'Disable'}
                            </Button>
                            <Button size="icon" variant="destructive" disabled={processing.has(member.id)} onClick={() => removeMember(member)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
