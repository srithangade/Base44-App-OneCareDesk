import React, { useCallback, useEffect, useState } from 'react';
import { Shield, UserPlus, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getUserManagementData } from '@/functions/getUserManagementData';
import { updateTeamMember } from '@/functions/updateTeamMember';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [agencies, setAgencies] = useState([]);
  const [inviteEmail, setInviteEmail] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const current = await base44.auth.me();
      if (current.role !== 'admin') throw new Error('forbidden');
      const response = await getUserManagementData({});
      setUsers(response.data?.users || []);
      setAgencies(response.data?.agencies || []);
    } catch {
      setMessage('Platform-administrator access is required.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const inviteUser = async () => {
    setMessage('');
    try {
      await base44.auth.inviteUser(inviteEmail.trim().toLowerCase(), 'user');
      setInviteEmail('');
      setMessage('Base44 invitation sent. Assign the agency and role after the user accepts.');
    } catch {
      setMessage('The Base44 invitation could not be sent. No custom invitation was created.');
    }
  };

  const assignUser = async (user, field, value) => {
    try {
      const updates = { [field]: value };
      if (field === 'app_role') updates.membership_status = 'active';
      await updateTeamMember({ user_id: user.id, updates });
      await loadData();
    } catch {
      setMessage('The assignment could not be saved.');
    }
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6 p-6">
      <div><h1 className="flex items-center gap-2 text-2xl font-bold"><Users className="h-6 w-6" /> Platform user management</h1></div>
      <Alert><Shield className="h-4 w-4" /><AlertDescription>Platform administrator status is the Base44 built-in admin role. It cannot be granted from this page.</AlertDescription></Alert>
      {message && <Alert><AlertDescription>{message}</AlertDescription></Alert>}
      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><UserPlus className="h-5 w-5" /> Managed invitation</CardTitle></CardHeader>
        <CardContent className="flex gap-2">
          <Input type="email" value={inviteEmail} onChange={(event) => setInviteEmail(event.target.value)} placeholder="user@example.com" />
          <Button onClick={inviteUser} disabled={!inviteEmail.trim()}>Invite with Base44</Button>
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Users</CardTitle></CardHeader>
        <CardContent>
          {loading ? <p>Loading users…</p> : (
            <Table>
              <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Base44 role</TableHead><TableHead>Agency</TableHead><TableHead>Application role</TableHead></TableRow></TableHeader>
              <TableBody>{users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell><div>{user.full_name || 'Unnamed user'}</div><div className="text-xs text-slate-500">{user.email}</div></TableCell>
                  <TableCell><Badge>{user.role}</Badge></TableCell>
                  <TableCell>
                    {user.role === 'admin' ? 'Platform-wide' : (
                      <Select value={user.agency_id || ''} onValueChange={(agency_id) => assignUser(user, 'agency_id', agency_id)}>
                        <SelectTrigger className="w-48"><SelectValue placeholder="Assign agency" /></SelectTrigger>
                        <SelectContent>{agencies.map((agency) => <SelectItem key={agency.id} value={agency.id}>{agency.name}</SelectItem>)}</SelectContent>
                      </Select>
                    )}
                  </TableCell>
                  <TableCell>
                    {user.role === 'admin' ? 'platform_admin' : (
                      <Select value={user.app_role || ''} onValueChange={(app_role) => assignUser(user, 'app_role', app_role)}>
                        <SelectTrigger className="w-44"><SelectValue placeholder="Assign role" /></SelectTrigger>
                        <SelectContent>
                          {['agency_admin', 'care_manager', 'caregiver', 'read_only'].map((role) => <SelectItem key={role} value={role}>{role}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    )}
                  </TableCell>
                </TableRow>
              ))}</TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
