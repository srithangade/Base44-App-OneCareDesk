import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Eye } from "lucide-react";

export default function ReviewRequests() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center gap-4 mb-6">
        <Eye className="w-8 h-8 text-gray-700" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Review Requests</h1>
          <p className="text-gray-600">Review and approve pending requests.</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Review Queue</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <Eye className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No pending reviews</h3>
            <p className="text-gray-500">Review requests will appear here when submitted.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}