import React from 'react';

export default function PrototypeNotice() {
  return (
    <div className="bg-amber-100 border-b border-amber-300 px-4 py-2 text-center text-sm font-medium text-amber-950">
      OneCareDesk is a development prototype and has not been verified for HIPAA compliance or production handling of protected health information.
    </div>
  );
}
