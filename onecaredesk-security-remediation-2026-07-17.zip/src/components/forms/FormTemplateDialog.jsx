import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, AlertTriangle, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function FormTemplateDialog({ open, onOpenChange, onSubmit, template }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    provider: "JotForm",
    form_url: "",
    embed_code: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (template) {
      setFormData({
        name: template.name || "",
        description: template.description || "",
        provider: template.provider || "JotForm",
        form_url: template.form_url || "",
        embed_code: template.embed_code || "",
      });
    } else {
      resetForm();
    }
  }, [template, open]);

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      provider: "JotForm",
      form_url: "",
      embed_code: "",
    });
    setError(null);
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.form_url) {
      setError("Template Name and Form URL are required.");
      return;
    }

    setError(null);
    setIsSubmitting(true);
    try {
      await onSubmit(formData);
      onOpenChange(false);
    } catch (err) {
      setError(err.message || "An error occurred.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{template ? "Edit" : "Create"} Form Template</DialogTitle>
          <DialogDescription>
            Add or edit a form template. Paste the direct public URL of your form.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {error && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Go to your form provider, click "Publish" or "Share", and copy the main public link for your form.
            </AlertDescription>
          </Alert>

          <div>
            <Label htmlFor="name">Template Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="e.g., Patient Intake Form"
            />
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="A short description of the form's purpose"
            />
          </div>
          <div>
            <Label htmlFor="provider">Form Provider</Label>
            <Select
              value={formData.provider}
              onValueChange={(value) => handleChange("provider", value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="JotForm">JotForm</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="form_url">Form URL *</Label>
            <Input
              id="form_url"
              value={formData.form_url}
              onChange={(e) => handleChange("form_url", e.target.value)}
              placeholder="https://form.jotform.com/your-form-id"
              className="font-mono"
            />
          </div>

          <details className="text-sm text-gray-500">
            <summary>Advanced: Use Embed Code</summary>
            <div className="mt-2 space-y-2">
                <Label htmlFor="embed_code">Embed Code (Optional)</Label>
                <Textarea
                  id="embed_code"
                  value={formData.embed_code}
                  onChange={(e) => handleChange("embed_code", e.target.value)}
                  placeholder="Paste the full HTML embed code here if a direct URL is not available."
                  rows={6}
                  className="font-mono"
                />
            </div>
          </details>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Template"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}