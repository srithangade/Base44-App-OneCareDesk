import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, Copy, AlertTriangle } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function FormTemplatePreviewDialog({ open, onOpenChange, template }) {
  const publicUrl = template ? `${window.location.origin}${createPageUrl(`FormViewer?id=${template.id}`)}` : '';
  const formUrl = template?.form_url;

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
    }
  };

  const openInNewTab = () => {
    if (publicUrl) {
      window.open(publicUrl, '_blank');
    }
  };

  if (!template) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Preview: {template.name}</span>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(publicUrl)}
                className="text-xs"
              >
                <Copy className="w-3 h-3 mr-1" />
                Copy Public URL
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={openInNewTab}
                className="text-xs"
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                Open in New Tab
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Form Preview */}
          <div className="border rounded-lg bg-gray-50">
            <div className="border-b bg-gray-100 px-4 py-2">
              <h3 className="font-medium text-gray-900">Live Preview</h3>
              <p className="text-sm text-gray-500">This is a live, interactive preview of the form.</p>
            </div>
            <div className="p-4">
              {formUrl ? (
                <iframe
                  src={formUrl}
                  title={template.name}
                  className="w-full h-[60vh] border rounded-md bg-white"
                  allow="geolocation; microphone; camera; payment"
                  allowFullScreen
                />
              ) : (
                <div className="flex flex-col items-center justify-center text-orange-600 bg-orange-100 p-8 rounded-lg min-h-[400px]">
                    <AlertTriangle className="w-12 h-12 mb-4" />
                    <h2 className="text-xl font-bold mb-2">Cannot Display Preview</h2>
                    <p className="text-center">A direct "Form URL" is missing from this template. Please edit it to add the URL.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
