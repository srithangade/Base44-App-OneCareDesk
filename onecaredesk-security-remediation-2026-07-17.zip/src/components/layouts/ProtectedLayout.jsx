
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import {
  Users as TeamIcon,
  UserCheck,
  Calendar,
  FileSignature,
  Settings,
  LogOut,
  Menu,
  HeartHandshake,
  Building,
  LayoutGrid,
  ClipboardCheck // A valid icon for Review Requests
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import HIPAAConsentDialog from "../auth/HIPAAConsentDialog";

export default function ProtectedLayout({ children, currentPageName }) {
  const [agency, setAgency] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showHIPAADialog, setShowHIPAADialog] = useState(false);
  const location = useLocation();
  const { user, isAuthenticated, isLoadingAuth, navigateToLogin, logout, refreshUser } = useAuth();

  useEffect(() => {
    const fetchUserAndAgency = async () => {
      if (isLoadingAuth) return;
      if (!isAuthenticated || !user) {
        navigateToLogin(window.location.href);
        return;
      }

      setIsLoading(true);
      try {
        const currentUser = user;

        if (!currentUser.hipaa_consent_given) {
          setShowHIPAADialog(true);
        }

        if (currentUser.agency_id) {
          const response = await base44.functions.invoke('getMyAgency');
          setAgency(response.data?.agency || response.agency || null);
        }
      } catch {
        setAgency(null);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUserAndAgency();
  }, [isAuthenticated, isLoadingAuth, navigateToLogin, user]);

  const handleConsent = async () => {
    try {
      await base44.auth.updateMe({
        hipaa_consent_given: true,
        hipaa_consent_date: new Date().toISOString(),
      });
      await refreshUser();
      setShowHIPAADialog(false);
    } catch {
      throw new Error('Unable to save the acknowledgement.');
    }
  };

  const handleLogout = () => logout('/');

  const navigationItems = [
    { label: 'Dashboard', icon: LayoutGrid, path: 'Dashboard' },
    { label: 'Lead Management', icon: UserCheck, path: 'Leads' },
    { label: 'Patients', icon: HeartHandshake, path: 'Patients' },
    { label: 'Care Givers', icon: UserCheck, path: 'Caregivers' },
    { label: 'Calendar', icon: Calendar, path: 'Calendar' },
    { label: 'E-Sign Requests', icon: FileSignature, path: 'Signatures' },
    { label: 'Review Requests', icon: ClipboardCheck, path: 'ReviewRequests' },
    { label: 'Team', icon: TeamIcon, path: 'Team' },
    { label: 'Settings', icon: Settings, path: 'Settings' },
  ];

  const getPageTitle = () => {
    const currentItem = navigationItems.find(item => item.path === currentPageName);
    return currentItem ? currentItem.label : "OneCareDesk";
  };
  
  if (isLoading || isLoadingAuth) {
    return (
      <div className="flex h-screen bg-gray-100">
        <div className="hidden lg:block w-64 bg-black p-4">
          <Skeleton className="h-8 w-3/4 mb-8 bg-gray-700" />
          <div className="space-y-4">
            {Array(8).fill(0).map((_, i) => <Skeleton key={i} className="h-8 w-full bg-gray-700" />)}
          </div>
        </div>
        <div className="flex-1 p-6">
          <Skeleton className="h-10 w-1/4 mb-6" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!user) {
     return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <HIPAAConsentDialog
        user={user}
        open={showHIPAADialog}
        onConsentGiven={handleConsent}
        onLogout={handleLogout}
      />
      
      {/* Mobile Header */}
      <div className="lg:hidden bg-white border-b border-gray-200 px-4 flex items-center justify-between h-16">
        <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0 bg-black">
            {/* Mobile Sidebar Content */}
            <div className="flex flex-col h-full">
              <div className="flex items-center gap-3 p-4 border-b border-gray-700 h-16">
                {agency?.logo_url ? (
                  <img src={agency.logo_url} alt="Agency Logo" className="h-8 w-8 rounded-md object-contain flex-shrink-0" />
                ) : (
                  <div className="h-8 w-8 flex items-center justify-center bg-gray-800 rounded-md flex-shrink-0">
                    <Building className="w-5 h-5 text-gray-400" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <h2 className="text-sm font-semibold text-white leading-tight">Compassionate Care</h2>
                  <p className="text-xs font-semibold text-gray-400 leading-tight">In Christ</p>
                </div>
              </div>
              <nav className="flex-1 px-4 py-6 space-y-2">
                {navigationItems.map((item) => {
                  const isActive = currentPageName === item.path;
                  return (
                    <Link
                      key={item.label}
                      to={createPageUrl(item.path)}
                      onClick={() => setIsSidebarOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors duration-200 ${
                        isActive
                          ? "bg-indigo-600 text-white shadow-lg"
                          : "text-gray-400 hover:bg-gray-800 hover:text-white"
                      }`}
                    >
                      <item.icon className="w-5 h-5" />
                      {item.label}
                    </Link>
                  );
                })}
              </nav>
              <div className="p-4 border-t border-gray-700">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <div className="flex items-center gap-3 cursor-pointer w-full text-left">
                      <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white font-semibold">
                        {user.full_name ? user.full_name.charAt(0).toUpperCase() : '?'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-white truncate">{user.full_name}</p>
                        <p className="text-xs text-gray-400 truncate">{user.email}</p>
                      </div>
                    </div>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 mb-2">
                    <DropdownMenuLabel>{user.full_name}</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="w-4 h-4 mr-2" />
                      <span>Log out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </SheetContent>
        </Sheet>
        <h1 className="text-lg font-bold text-gray-800">{getPageTitle()}</h1>
        <div>{/* Placeholder for right-side icons if any */}</div>
      </div>

      <div className="flex">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-black shadow-xl">
          <div className="flex flex-col flex-grow">
            <div className="flex items-center gap-3 p-4 border-b border-gray-700 h-16">
              {agency?.logo_url ? (
                <img src={agency.logo_url} alt="Agency Logo" className="h-8 w-8 rounded-md object-contain flex-shrink-0" />
              ) : (
                  <div className="h-8 w-8 flex items-center justify-center bg-gray-800 rounded-md flex-shrink-0">
                    <Building className="w-5 h-5 text-gray-400" />
                  </div>
                )}
              <div className="flex-1 min-w-0">
                <h2 className="text-sm font-semibold text-white leading-tight">Compassionate Care</h2>
                <p className="text-xs font-semibold text-gray-400 leading-tight">In Christ</p>
              </div>
            </div>
            <nav className="flex-1 px-4 py-6 space-y-2">
              {navigationItems.map((item) => {
                const isActive = currentPageName === item.path;
                return (
                  <Link
                    key={item.label}
                    to={createPageUrl(item.path)}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors duration-200 ${
                      isActive
                        ? "bg-indigo-600 text-white shadow-lg"
                        : "text-gray-400 hover:bg-gray-800 hover:text-white"
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
            <div className="p-4 border-t border-gray-700">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <div className="flex items-center gap-3 cursor-pointer w-full text-left">
                    <div className="w-9 h-9 rounded-full bg-indigo-500 flex items-center justify-center text-white font-semibold">
                      {user.full_name ? user.full_name.charAt(0).toUpperCase() : '?'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-white truncate">{user.full_name}</p>
                      <p className="text-xs text-gray-400 truncate">{user.email}</p>
                    </div>
                  </div>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 mb-2">
                  <DropdownMenuLabel>{user.full_name}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="w-4 h-4 mr-2" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="lg:pl-64 flex-1 min-h-screen">
          {/* The header that was here is removed as per the instructions. 
              The mobile header still exists for smaller screens. */}
          <div className="p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
