import React, { useState, useEffect } from 'react';

const TypingEffect = ({ phrases, className = '' }) => {
  const [phraseIndex, setPhraseIndex] = useState(0);
  const [text, setText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [loopNum, setLoopNum] = useState(0);
  const typingSpeed = 100;
  const deletingSpeed = 50;
  const pauseDuration = 1500;

  useEffect(() => {
    const handleTyping = () => {
      const currentPhrase = phrases[phraseIndex];
      const updatedText = isDeleting
        ? currentPhrase.substring(0, text.length - 1)
        : currentPhrase.substring(0, text.length + 1);

      setText(updatedText);

      if (!isDeleting && updatedText === currentPhrase) {
        setTimeout(() => setIsDeleting(true), pauseDuration);
      } else if (isDeleting && updatedText === '') {
        setIsDeleting(false);
        setPhraseIndex((prevIndex) => (prevIndex + 1) % phrases.length);
      }
    };

    const speed = isDeleting ? deletingSpeed : typingSpeed;
    const timer = setTimeout(handleTyping, speed);

    return () => clearTimeout(timer);
  }, [text, isDeleting, phraseIndex, phrases]);

  return (
    <>
      <style>{`
        .blinking-cursor {
          animation: blink 1s step-end infinite;
          font-weight: 300;
        }
        @keyframes blink {
          from, to { color: transparent }
          50% { color: #0ea5e9; } /* sky-500 */
        }
      `}</style>
      <span className={className}>
        {text}
        <span className="blinking-cursor">|</span>
      </span>
    </>
  );
};

export default TypingEffect;