import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import Logo from './Logo';

export default function PublicHeader() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex-shrink-0">
            <Logo size="medium" showSubtitle={false} linkTo="Home_new" />
          </div>
          <nav className="hidden md:flex md:space-x-8">
            <a href="#features" className="font-medium text-gray-600 hover:text-sky-600 transition-colors">Features</a>
            <Link to={createPageUrl('Pricing')} className="font-medium text-gray-600 hover:text-sky-600 transition-colors">Pricing</Link>
            <Link to={createPageUrl('About')} className="font-medium text-gray-600 hover:text-sky-600 transition-colors">About</Link>
            <Link to={createPageUrl('Contact')} className="font-medium text-gray-600 hover:text-sky-600 transition-colors">Contact</Link>
          </nav>
          <div className="hidden md:flex items-center space-x-4">
            <Link to={createPageUrl('Auth')} className="font-medium text-gray-600 hover:text-sky-600 transition-colors">
              Sign In
            </Link>
            <Button asChild className="bg-sky-600 hover:bg-sky-700">
              <Link to={createPageUrl('Contact')}>Request a Demo</Link>
            </Button>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}