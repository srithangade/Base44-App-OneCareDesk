import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertTriangle } from 'lucide-react';

export default function HIPAAConsentDialog({ user, open, onConsentGiven, onLogout }) {
  const [hasRead, setHasRead] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAccept = async () => {
    if (!hasRead || isSubmitting) return;
    setIsSubmitting(true);
    try {
      await onConsentGiven();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={() => {}} modal>
      <DialogContent className="max-w-xl" onInteractOutside={(event) => event.preventDefault()}>
        <DialogHeader>
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-7 w-7 text-amber-600" />
            <div>
              <DialogTitle>Development data-use notice</DialogTitle>
              <DialogDescription>
                Welcome, {user?.full_name || 'user'}. Review this limitation before continuing.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <div className="space-y-3 text-sm text-slate-700">
          <p>
            OneCareDesk is a development prototype. It has not been independently security reviewed, verified for HIPAA compliance, or approved to handle real protected health information.
          </p>
          <p>
            Use synthetic demo data only. Do not enter real patient, caregiver, clinical, insurance, signature, or background-check information.
          </p>
          <label className="flex items-start gap-2 rounded-md border p-3">
            <Checkbox checked={hasRead} onCheckedChange={setHasRead} />
            <span>I understand that this prototype must only contain synthetic data.</span>
          </label>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onLogout}>Decline and sign out</Button>
          <Button onClick={handleAccept} disabled={!hasRead || isSubmitting}>
            {isSubmitting ? 'Saving…' : 'Acknowledge'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
