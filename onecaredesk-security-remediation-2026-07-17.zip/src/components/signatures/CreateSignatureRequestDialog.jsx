
import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, AlertTriangle, UserPlus, X, FileText, CheckCircle, Mail } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { FormTemplate } from "@/entities/FormTemplate";
import { SignatureRequest } from "@/entities/SignatureRequest";
// Import Agency

// New import for email sending functionality
import { sendEsignEmail } from "@/functions/sendEsignEmail";

export default function CreateSignatureRequestDialog({
  open,
  onOpenChange,
  onCreateRequest, // Retaining existing prop name
  relatedEntity,
}) {
  const [title, setTitle] = useState("");
  const [formTemplateId, setFormTemplateId] = useState("");
  const [customMessage, setCustomMessage] = useState("");
  const [recipients, setRecipients] = useState([]);
  const [formTemplates, setFormTemplates] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false); // Used for "isSending" from outline
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  // `agency` state is no longer strictly needed on the frontend if `sendEsignEmail`
  // on the backend fetches agency details for branding. Removing for cleaner state.
  // const [agency, setAgency] = useState(null); 

  const resetForm = () => {
    setTitle("");
    setFormTemplateId("");
    setCustomMessage("");
    setRecipients([]);
    setError(null);
    setSuccess(null);
    setIsSubmitting(false);
  };

  const fetchTemplates = useCallback(async () => {
    setIsLoading(true);
    try {
      const user = await base44.auth.me();
      if (!user?.agency_id) {
        throw new Error("User agency not found.");
      }
      const templates = await FormTemplate.filter({ agency_id: user.agency_id });
      setFormTemplates(templates);
    } catch (err) {
      setError("Failed to load form templates.");
    } finally {
      setIsLoading(false);
    }
  }, []); // Dependencies are stable setters

  const loadInitialData = useCallback(async () => {
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);
    } catch {
      setError("Failed to load initial user data.");
    }
    await fetchTemplates();
  }, [fetchTemplates]); // `setAgency`, `setCurrentUser`, `setError` are stable setters

  useEffect(() => {
    if (open) {
      resetForm();
      loadInitialData();
    }
  }, [open, loadInitialData]);

  useEffect(() => {
    if (relatedEntity && open) {
      const recipientName = relatedEntity.name || `${relatedEntity.first_name} ${relatedEntity.last_name}`;
      const recipientEmail = relatedEntity.email || "";
      setRecipients([{ 
        name: recipientName, 
        email: recipientEmail
      }]);
    }
  }, [relatedEntity, open]);

  const handleTemplateChange = (templateId) => {
    setFormTemplateId(templateId);
    const selectedTemplate = formTemplates.find(t => t.id === templateId);
    if (selectedTemplate) {
      setTitle(`E-Sign Request - ${selectedTemplate.name}`);
    }
  };

  const handleRecipientChange = (index, field, value) => {
    const newRecipients = [...recipients];
    newRecipients[index][field] = value;
    setRecipients(newRecipients);
  };

  const addRecipient = () => {
    setRecipients([...recipients, { name: "", email: "" }]);
  };

  const removeRecipient = (index) => {
    setRecipients(recipients.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    // Validation
    if (!title || !formTemplateId || recipients.length === 0) {
      setError("Please select a document and fill out all required fields.");
      return;
    }

    const invalidRecipients = recipients.filter(r => !r.name || !r.email || !r.email.includes('@')); // Basic email format validation
    if (invalidRecipients.length > 0) {
      setError("Please fill in valid name and email for all recipients.");
      return;
    }

    if (!currentUser?.agency_id) {
      setError("Unable to determine your agency. Please refresh and try again.");
      return;
    }

    const selectedTemplate = formTemplates.find(t => t.id === formTemplateId);
    if (!selectedTemplate) {
        setError("Selected document template not found.");
        return;
    }

    setIsSubmitting(true);
    
    try {
      // Create the signature request
      const requestData = {
        agency_id: currentUser.agency_id,
        title,
        form_template_id: formTemplateId,
        recipients,
        related_entity_id: relatedEntity?.id,
        related_entity_type: relatedEntity?.first_name ? "patient" : "lead", // This logic might need refinement based on exact entity types
        status: "sent", // Start as 'sent' as emails are sent immediately
        provider: "jotform", // Consistent with existing code
        external_request_id: selectedTemplate?.external_form_id, // JotForm ID
        sent_date: new Date().toISOString(),
        custom_message: customMessage,
        notes: `Created from ${relatedEntity?.name || 'manual entry'}`
      };

      const createdRequest = await SignatureRequest.create(requestData);

      // Now, call the backend function to send the email(s)
      // This replaces the previous frontend email construction and `EmailService.send` logic.
      const { data: emailResult, error: emailError } = await sendEsignEmail({ signatureRequestId: createdRequest.id });

      if (emailError) {
        // If there's an error from the email sending function, throw it to be caught
        throw new Error(emailError.message || "Failed to send emails for the signature request.");
      }

      // Assuming `emailResult` from `sendEsignEmail` contains a `success` flag and `sentCount`
      if (emailResult && emailResult.success) {
        const sentCount = emailResult.sentCount || recipients.length; // Fallback to all if backend doesn't provide count
        setSuccess(`✅ E-signature request created and emails sent successfully! 
        📧 ${sentCount} email${sentCount > 1 ? 's' : ''} sent.`);
        
        // Notify parent component on success
        if (onCreateRequest) {
          onCreateRequest(createdRequest);
        }
        // Close the dialog only on successful completion
        onOpenChange(false);
      } else {
        // If `emailResult` exists but indicates failure or partially sent
        setError(`❌ E-signature request created, but there was an issue sending emails: ${emailResult?.message || 'Unknown email sending error'}`);
        // Do not close dialog if there was an email sending issue
      }

    } catch (err) {
      setError(`Failed to create or send signature request: ${err.message || 'Unknown error occurred'}`);
    } finally {
      setIsSubmitting(false); // Always reset submitting state
    }
  };

  const handleClose = () => {
    if (!isSubmitting) { // Prevent closing while submitting
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl bg-blue-50 border-blue-200">
        <DialogHeader className="p-6 border-b bg-gradient-to-r from-blue-100 to-blue-50 border-blue-200">
          <DialogTitle className="flex items-center gap-2 text-xl text-blue-900">
            <FileText className="w-5 h-5 text-blue-600" />
            New E-Signature Request
          </DialogTitle>
          <DialogDescription className="text-blue-700">
            Select a document, add recipients, and send it for signature.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 p-6">
          {error && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="whitespace-pre-line">{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="bg-green-50 border-green-200 text-green-800">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="whitespace-pre-line">{success}</AlertDescription>
            </Alert>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="form-template" className="text-blue-800 font-medium">Select Document *</Label>
            <Select onValueChange={handleTemplateChange} value={formTemplateId} disabled={isLoading}>
              <SelectTrigger id="form-template" className="bg-white border-blue-300">
                <SelectValue placeholder={isLoading ? "Loading templates..." : "Select a document to send"} />
              </SelectTrigger>
              <SelectContent>
                {formTemplates.map((template) => (
                  <SelectItem key={template.id} value={template.id}>
                    {template.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="request-title" className="text-blue-800 font-medium">Request Title *</Label>
            <Input
              id="request-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., E-Sign Request - Patient Intake Form"
              className="bg-white border-blue-300"
            />
          </div>

          <div className="space-y-3">
            <Label className="text-blue-800 font-medium">Recipients *</Label>
            {recipients.map((recipient, index) => (
              <div key={index} className="flex items-center gap-2 p-3 border border-blue-300 rounded-md bg-white">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 flex-1">
                  <Input
                    placeholder="Full Name"
                    value={recipient.name}
                    onChange={(e) => handleRecipientChange(index, 'name', e.target.value)}
                    className="border-blue-200"
                  />
                  <Input
                    type="email"
                    placeholder="Email Address"
                    value={recipient.email}
                    onChange={(e) => handleRecipientChange(index, 'email', e.target.value)}
                    className="border-blue-200"
                  />
                </div>
                {recipients.length > 1 && (
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeRecipient(index)}>
                    <X className="w-4 h-4 text-red-500" />
                  </Button>
                )}
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" onClick={addRecipient} className="bg-white border-blue-300 text-blue-700 hover:bg-blue-50">
              <UserPlus className="w-4 h-4 mr-2" />
              Add Another Recipient
            </Button>
          </div>

          <div className="space-y-2">
            <Label htmlFor="custom-message" className="text-blue-800 font-medium">Custom Message (Optional)</Label>
            <Textarea
              id="custom-message"
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              placeholder="Add a personal message to include in the signature request email..."
              className="bg-white border-blue-300"
              rows={3}
            />
          </div>

          <DialogFooter className="pt-6 border-t border-blue-200">
            <Button 
              type="button" 
              variant="ghost" 
              onClick={handleClose} 
              disabled={isSubmitting}
              className="text-blue-700 hover:bg-blue-100"
            >
              {success ? 'Close' : 'Cancel'}
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || isLoading || !formTemplateId || recipients.some(r => !r.name || !r.email || !r.email.includes('@')) || !title} // More comprehensive disabling
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Mail className="w-4 h-4 mr-2" />
                  Send Request
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
