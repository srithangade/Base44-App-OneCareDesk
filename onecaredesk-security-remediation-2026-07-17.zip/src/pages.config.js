import Dashboard from './pages/Dashboard';
import Leads from './pages/Leads';
import Patients from './pages/Patients';
import Caregivers from './pages/Caregivers';
import Calendar from './pages/Calendar';
import Signatures from './pages/Signatures';
import PDFEditor from './pages/PDFEditor';
import Settings from './pages/Settings';
import Architecture from './pages/Architecture';
import UserManagement from './pages/UserManagement';
import Landing from './pages/Landing';
import ServiceAgreement from './pages/ServiceAgreement';
import Home from './pages/Home';
import Agencies from './pages/Agencies';
import Auth from './pages/Auth';
import Features from './pages/Features';
import About from './pages/About';
import Contact from './pages/Contact';
import Pricing from './pages/Pricing';
import homeNew from './pages/Home_new';
import FormViewer from './pages/FormViewer';
import SignedDocuments from './pages/SignedDocuments';
import FormTemplates from './pages/FormTemplates';
import TrialRequest from './pages/TrialRequest';
import ReviewRequests from './pages/ReviewRequests';
import Team from './pages/Team';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Dashboard": Dashboard,
    "Leads": Leads,
    "Patients": Patients,
    "Caregivers": Caregivers,
    "Calendar": Calendar,
    "Signatures": Signatures,
    "PDFEditor": PDFEditor,
    "Settings": Settings,
    "Architecture": Architecture,
    "UserManagement": UserManagement,
    "Landing": Landing,
    "ServiceAgreement": ServiceAgreement,
    "Home": Home,
    "Agencies": Agencies,
    "Auth": Auth,
    "Features": Features,
    "About": About,
    "Contact": Contact,
    "Pricing": Pricing,
    "Home_new": homeNew,
    "FormViewer": FormViewer,
    "SignedDocuments": SignedDocuments,
    "FormTemplates": FormTemplates,
    "TrialRequest": TrialRequest,
    "ReviewRequests": ReviewRequests,
    "Team": Team,
}

export const pagesConfig = {
    mainPage: "Home_new",
    Pages: PAGES,
    Layout: __Layout,
};
