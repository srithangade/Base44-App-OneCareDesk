import React from 'react';
import ProtectedLayout from './components/layouts/ProtectedLayout';
import PrototypeNotice from './components/compliance/PrototypeNotice';
import { isPublicPage } from './lib/routeAccess';

export default function Layout({ children, currentPageName }) {
  let effectivePageName = currentPageName;
  if (!effectivePageName && typeof window !== 'undefined' && window.location.pathname === '/') {
    effectivePageName = 'Home_new';
  }

  const content = isPublicPage(effectivePageName)
    ? children
    : <ProtectedLayout currentPageName={effectivePageName}>{children}</ProtectedLayout>;

  return (
    <>
      <PrototypeNotice />
      {content}
    </>
  );
}
