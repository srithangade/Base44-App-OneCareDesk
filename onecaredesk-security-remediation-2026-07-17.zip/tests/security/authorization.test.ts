import { describe, expect, it, vi } from 'vitest';
import {
  errorResponse,
  getAuthorizedAgencyId,
  requireAgencyRole,
  requireAuthenticatedUser,
  requirePlatformAdmin,
  requireRecordAccess,
  sanitizeUserUpdates,
  securityLog,
} from '../../base44/functions/_shared/security';

const agencyAdmin = {
  id: 'user-agency-a',
  email: 'admin@example.invalid',
  agencyId: 'agency-a',
  appRole: 'agency_admin',
  isPlatformAdmin: false,
};

const regularUser = {
  ...agencyAdmin,
  id: 'user-regular',
  appRole: 'caregiver',
};

const platformAdmin = {
  ...agencyAdmin,
  id: 'user-platform',
  agencyId: null,
  appRole: 'platform_admin',
  isPlatformAdmin: true,
};

describe('managed identity boundary', () => {
  it('rejects an unauthenticated caller before any elevated client is touched', async () => {
    let serviceRoleTouched = false;
    const base44 = {
      auth: { me: vi.fn().mockRejectedValue(new Error('not authenticated')) },
      get asServiceRole() {
        serviceRoleTouched = true;
        return {};
      },
    };

    await expect(requireAuthenticatedUser(base44)).rejects.toMatchObject({
      status: 401,
      category: 'unauthenticated',
    });
    expect(serviceRoleTouched).toBe(false);
  });

  it('accepts the built-in Base44 platform-admin role only from the managed user', async () => {
    const base44 = {
      auth: {
        me: vi.fn().mockResolvedValue({
          id: 'managed-user',
          email: 'platform@example.invalid',
          role: 'admin',
        }),
      },
    };
    const principal = await requireAuthenticatedUser(base44);
    expect(requirePlatformAdmin(principal).isPlatformAdmin).toBe(true);
  });

  it('rejects a non-platform user whose agency membership is not active', async () => {
    const base44 = {
      auth: {
        me: vi.fn().mockResolvedValue({
          id: 'pending-user',
          email: 'pending@example.invalid',
          role: 'user',
          app_role: 'caregiver',
          agency_id: 'agency-a',
          membership_status: 'pending',
        }),
      },
    };
    await expect(requireAuthenticatedUser(base44)).rejects.toMatchObject({
      status: 403,
      category: 'membership_inactive',
    });
  });
});

describe('tenant and role authorization', () => {
  it('prevents Agency A from reading, updating, or deleting an Agency B record', () => {
    const agencyBRecord = { id: 'record-b', agency_id: 'agency-b' };
    for (const operation of ['read', 'update', 'delete']) {
      expect(() => requireRecordAccess(agencyAdmin, agencyBRecord), operation)
        .toThrowError(expect.objectContaining({ status: 403, category: 'cross_tenant_forbidden' }));
    }
  });

  it('rejects a client-supplied agency override', () => {
    expect(() => getAuthorizedAgencyId(agencyAdmin, 'agency-b')).toThrowError(
      expect.objectContaining({ status: 403, category: 'cross_tenant_forbidden' }),
    );
    expect(getAuthorizedAgencyId(agencyAdmin, 'agency-a')).toBe('agency-a');
    expect(() => sanitizeUserUpdates(agencyAdmin, {
      agency_id: 'agency-a', role: 'user', app_role: 'caregiver',
    }, { agency_id: 'agency-b' })).toThrowError(
      expect.objectContaining({ status: 403, category: 'cross_tenant_forbidden' }),
    );
  });

  it('does not accept client-side state as an authorization input', () => {
    const attackerControlledStorage = JSON.stringify({
      role: 'admin',
      agency_id: 'agency-b',
    });
    expect(attackerControlledStorage).toContain('admin');
    expect(() => requireRecordAccess(regularUser, { agency_id: 'agency-b' })).toThrow();
  });

  it('prevents a regular user from granting an administrator role', () => {
    expect(() => sanitizeUserUpdates(regularUser, { agency_id: 'agency-a' }, {
      app_role: 'agency_admin',
    })).toThrowError(expect.objectContaining({ category: 'role_escalation_forbidden' }));
  });

  it('prevents an agency administrator from granting a platform role or changing agency', () => {
    expect(() => sanitizeUserUpdates(agencyAdmin, {
      agency_id: 'agency-a', role: 'user', app_role: 'caregiver',
    }, { app_role: 'platform_admin' }))
      .toThrowError(expect.objectContaining({ category: 'role_escalation_forbidden' }));
  });

  it('allows only configured agency management roles through the role gate', () => {
    expect(() => requireAgencyRole(regularUser, ['agency_admin', 'care_manager'])).toThrowError(
      expect.objectContaining({ status: 403, category: 'role_forbidden' }),
    );
    expect(requireAgencyRole(agencyAdmin, ['agency_admin'])).toBe(agencyAdmin);
    expect(requirePlatformAdmin(platformAdmin)).toBe(platformAdmin);
  });
});

describe('redacted failures and logging', () => {
  it('uses a generic response for unexpected backend errors', async () => {
    const response = errorResponse(new Error('account alice@example.invalid exists'));
    expect(response.status).toBe(500);
    expect(await response.json()).toEqual({ error: 'The request could not be completed.' });
  });

  it('does not serialize emails, phone numbers, patient records, or arbitrary fields', () => {
    const spy = vi.spyOn(console, 'info').mockImplementation(() => undefined);
    securityLog('record.denied', {
      result: 'denied',
      userId: 'managed-user-123456',
      agencyId: 'agency-a-123456',
      email: 'person@example.invalid',
      phone: '555-555-5555',
      patient: { diagnosis: 'sensitive' },
    });
    const serialized = String(spy.mock.calls[0][0]);
    expect(serialized).not.toContain('person@example.invalid');
    expect(serialized).not.toContain('555-555-5555');
    expect(serialized).not.toContain('diagnosis');
    expect(serialized).toContain('mana...3456');
    spy.mockRestore();
  });
});
