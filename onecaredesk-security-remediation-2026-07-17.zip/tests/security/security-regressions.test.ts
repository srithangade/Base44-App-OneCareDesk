import { describe, expect, it } from 'vitest';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { isPublicPage } from '../../src/lib/routeAccess';

const root = process.cwd();

const filesUnder = (directory: string): string[] => readdirSync(directory).flatMap((name) => {
  const path = join(directory, name);
  return statSync(path).isDirectory() ? filesUnder(path) : [path];
});

const productionFiles = [
  ...filesUnder(join(root, 'src')),
  ...filesUnder(join(root, 'base44')),
].filter((path) => /\.(?:js|jsx|ts|tsx|jsonc)$/.test(path));

const productionSource = () => productionFiles
  .map((path) => `\n/* ${relative(root, path)} */\n${readFileSync(path, 'utf8')}`)
  .join('\n');

describe('custom authentication remains removed', () => {
  it('contains no application-managed password hashes, salt, or app_user session', () => {
    const source = productionSource();
    for (const forbidden of [
      /ONECARE_SALT/i,
      /createHash\s*\(/,
      /password_hash/i,
      /currentHash/,
      /newHash/,
      /temp_password/i,
      /localStorage\.getItem\s*\(\s*['"]app_user['"]\s*\)/,
    ]) {
      expect(source).not.toMatch(forbidden);
    }
  });

  it('does not restore custom login, reset, super-admin, emergency, or debug endpoints', () => {
    const forbiddenEntries = [
      'auth', 'requestPasswordReset', 'resetPassword', 'fixPassword',
      'createSuperAdmin', 'initializeSuperAdmin', 'emergencyLogin',
      'debugLogin', 'debugAuth', 'resetTeamMemberPassword',
    ];
    for (const name of forbiddenEntries) {
      expect(() => statSync(join(root, 'base44', 'functions', name, 'entry.ts'))).toThrow();
    }
  });

  it('has no browser-console logging of records or identifiers', () => {
    const clientSource = filesUnder(join(root, 'src'))
      .filter((path) => /\.(?:js|jsx|ts|tsx)$/.test(path))
      .map((path) => readFileSync(path, 'utf8'))
      .join('\n');
    expect(clientSource).not.toMatch(/console\.(?:log|debug|info|warn|error)\s*\(/);
  });

  it('uses only reserved synthetic contact literals in client source', () => {
    const clientSource = filesUnder(join(root, 'src'))
      .filter((path) => /\.(?:js|jsx|ts|tsx)$/.test(path))
      .map((path) => readFileSync(path, 'utf8'))
      .join('\n');
    const emails = clientSource.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
    expect(emails.every((email) => /@(example\.(?:com|org|net)|example\.invalid)$/i.test(email))).toBe(true);
    const phoneNumbers = clientSource.match(/\b\d{3}[-. )]+\d{3}[-. ]+\d{4}\b/g) || [];
    expect(phoneNumbers.every((phone) => /555[-. ]01\d{2}$/.test(phone))).toBe(true);
  });
});

describe('protected routes', () => {
  it('keeps operational and administrative pages behind managed authentication', () => {
    for (const page of [
      'Dashboard', 'Leads', 'Patients', 'Caregivers', 'Calendar', 'Signatures',
      'Team', 'UserManagement', 'Settings', 'FormViewer', 'SignedDocuments',
    ]) {
      expect(isPublicPage(page), page).toBe(false);
    }
  });

  it('allows only intentional marketing and managed-auth entry pages publicly', () => {
    expect(isPublicPage('Home_new')).toBe(true);
    expect(isPublicPage('Auth')).toBe(true);
    expect(isPublicPage('ThankYou')).toBe(false);
  });
});

describe('service-role ordering', () => {
  it('requires managed authentication or a webhook secret before each service-role use', () => {
    const functionEntries = filesUnder(join(root, 'base44', 'functions'))
      .filter((path) => path.endsWith('entry.ts'));

    for (const path of functionEntries) {
      const source = readFileSync(path, 'utf8');
      const serviceRoleIndex = source.indexOf('asServiceRole');
      if (serviceRoleIndex === -1) continue;
      const authIndex = source.indexOf('requireAuthenticatedUser');
      const webhookIndex = source.indexOf('requireWebhookBearerSecret');
      const guardIndexes = [authIndex, webhookIndex].filter((index) => index !== -1);
      expect(guardIndexes.length, relative(root, path)).toBeGreaterThan(0);
      expect(Math.min(...guardIndexes), relative(root, path)).toBeLessThan(serviceRoleIndex);
    }
  });
});
